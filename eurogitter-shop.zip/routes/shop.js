// ============================================================
//  Shop-Routen (Gitterbox-Shop): Startseite, Sortiment, Produkt, Warenkorb, Kasse, Kontakt
// ============================================================
const { Router } = require('../lib/app');
const router = Router();
const db = require('../db');
const h = require('../lib/helpers');
const { sendMail } = require('../lib/mailer');
const emails = require('../lib/emails');
const geo = require('../lib/geo');
const cart = require('../lib/cart');
const ratings = require('../lib/ratings');
const ids = require('../lib/ids');
const inventory = require('../lib/inventory');
const brand = require('../lib/brand');
const sellerLib = require('../lib/seller');

// Heartbeat: haelt die Live-Praesenz aktuell (Praesenz selbst wird in server.js erfasst).
router.get('/aktiv', (req, res) => { res.statusCode = 204; res.end(); });

// ---------- SEO: robots.txt + sitemap.xml ----------
function siteBase() { return (process.env.BASE_URL || brand.fallbackBaseUrl).replace(/\/+$/, ''); }
router.get('/robots.txt', (req, res) => {
  const base = siteBase();
  res.setHeader('Content-Type', 'text/plain; charset=utf-8');
  res.send(`User-agent: *\nAllow: /\nDisallow: /admin\nDisallow: /konto\nDisallow: /kasse\nDisallow: /warenkorb\nDisallow: /login\nDisallow: /registrieren\n\nSitemap: ${base}/sitemap.xml\n`);
});
router.get('/sitemap.xml', (req, res) => {
  const base = siteBase();
  const staticUrls = ['/', '/produkte', '/produkte?gruppe=gitterbox', '/produkte?gruppe=gebraucht', '/produkte?gruppe=palette', '/kontakt', '/karriere', '/impressum', '/agb', '/datenschutz'];
  let prods = [];
  try { prods = db.prepare('SELECT slug FROM products WHERE active = 1 ORDER BY sort_order, id').all(); } catch (e) {}
  const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;');
  let xml = '<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n';
  for (const u of staticUrls) xml += `  <url><loc>${esc(base + u)}</loc></url>\n`;
  for (const pr of prods) xml += `  <url><loc>${esc(base + '/produkt/' + pr.slug)}</loc></url>\n`;
  xml += '</urlset>\n';
  res.setHeader('Content-Type', 'application/xml; charset=utf-8');
  res.send(xml);
});

// ---------- Warenkorb-Helfer ----------
function buildCart(session, settings) {
  syncAddons(session);
  const c = session.cart || {};
  const keys = Object.keys(c);
  if (keys.length === 0) return { items: [], totals: h.totals([], 19, 0) };
  const pids = [...new Set(keys.map(k => c[k].product_id))];
  const rows = db.prepare(`SELECT * FROM products WHERE id IN (${pids.map(() => '?').join(',')})`).all(...pids);
  const byId = {}; rows.forEach(r => { byId[r.id] = r; });
  const items = keys.map(k => {
    const line = c[k]; const p = byId[line.product_id];
    if (!p) return null;
    const isSet = !!line.set;
    return { product: p, key: k, id: p.id, name: p.name + (isSet ? ' – Set-Preis mit Gitterbox' : ''), type: p.type, unit_cents: isSet ? ADDON.setCents : p.price_cents, regular_cents: p.price_cents, set: isSet, set_min: line.min || 1, set_max: line.max || (Number(line.quantity) || 1), quantity: Number(line.quantity) || 1, color: line.color || null };
  }).filter(Boolean);
  return { items, totals: h.totals(items, 19, shipCents(settings, items)) };
}
function persistCart(req) { if (req.user) cart.saveUserCart(req.user.id, req.session.cart || {}); }
function cartSummary(session) {
  syncAddons(session);
  const c = session.cart || {};
  const keys = Object.keys(c);
  let count = 0, net = 0;
  if (keys.length) {
    const pids = [...new Set(keys.map(k => c[k] && c[k].product_id).filter(Boolean))];
    if (pids.length) {
      const rows = db.prepare(`SELECT id, price_cents FROM products WHERE id IN (${pids.map(() => '?').join(',')})`).all(...pids);
      const price = {}; rows.forEach(r => { price[r.id] = r.price_cents; });
      keys.forEach(k => { const l = c[k]; if (!l) return; const q = Number(l.quantity) || 0; count += q; net += (l.set ? ADDON.setCents : (price[l.product_id] || 0)) * q; });
    }
  }
  return { count, gross: Math.round(net * 1.19) };
}
// Speditions-Versandkosten (netto): bei aktiver Aktion kostenlos, sonst GRUNDPREIS
// (Anfahrt, deutschlandweit) + Aufpreis je Gitterbox. EU-Paletten zaehlen mit 1/5 je Stueck.
function shipCents(settings, items) {
  const s = settings || {};
  if (s.promo_active) return 0;
  const base = Number(s.ship_base_cents) || 0;
  const perBox = Number(s.ship_perbox_cents) || 0;
  if (!items || !items.length) return 0;
  let boxes = 0, pal = 0;
  items.forEach(it => {
    const g = (it.product && it.product.product_group) || '';
    const q = Number(it.quantity) || 0;
    if (g === 'palette') pal += q; else boxes += q;
  });
  if (boxes === 0 && pal === 0) return 0;
  return base + perBox * boxes + Math.round(perBox / 5) * pal;
}
function sendJson(res, obj) { res.setHeader('Content-Type', 'application/json; charset=utf-8'); res.send(JSON.stringify(obj)); }
const WITH_IMG = "active = 1 AND image IS NOT NULL AND image != ''";
// Zusatzoption: Trennwaende zum Set-Preis (1 je Box) bei den tauschfaehigen DB-Europool-Boxen (neu + gebraucht).
// Die Set-Position im Warenkorb (Schluessel 'tw-set') folgt automatisch der Stueckzahl dieser Boxen.
const ADDON = { slug: 'gitterbox-trennwand', setCents: 3000, minQty: 10, hosts: ['db-europool-gitterbox-halbe-klappe', 'db-europool-gitterbox-halbe-klappe-gebraucht'], key: 'tw-set' };
function syncAddons(session) {
  const c = session.cart || {}; const line = c[ADDON.key]; if (!line) return 0;
  const keys = Object.keys(c).filter(k => k !== ADDON.key);
  const pids = [...new Set(keys.map(k => c[k] && c[k].product_id).filter(Boolean))];
  let hosts = 0;
  if (pids.length) {
    const rows = db.prepare(`SELECT id, slug FROM products WHERE id IN (${pids.map(() => '?').join(',')})`).all(...pids);
    const hostIds = new Set(rows.filter(r => ADDON.hosts.includes(r.slug)).map(r => r.id));
    keys.forEach(k => { const l = c[k]; if (l && hostIds.has(l.product_id)) hosts += Number(l.quantity) || 0; });
  }
  if (hosts <= 0) { delete c[ADDON.key]; return 0; }
  // Neu im Korb: eine Trennwand je Box. Danach darf der Kunde reduzieren - mindestens 10 (bzw. Boxenzahl), hoechstens so viele wie Boxen.
  const min = Math.min(ADDON.minQty, hosts);
  const q = Number(line.quantity) || 0;
  line.quantity = q <= 0 ? hosts : Math.max(min, Math.min(hosts, q));
  line.min = min; line.max = hosts;
  return hosts;
}

// ---------- Startseite ----------
router.get('/', (req, res) => {
  // Highlight-Karte der Startseite: die gebrauchte, EPAL-tauschfaehige DB-Europool-Box; Rueckfall auf den Bestseller der Neuware
  let featured = db.prepare(`SELECT * FROM products WHERE ${WITH_IMG} AND slug = 'db-europool-gitterbox-halbe-klappe-gebraucht' AND sold_out = 0 LIMIT 1`).all();
  if (!featured.length) featured = db.prepare(`SELECT * FROM products WHERE ${WITH_IMG} AND product_group = 'gitterbox' ORDER BY bestseller DESC, sort_order, id LIMIT 1`).all();
  // Startseiten-Karte: gibt es zum Hauptbild eine "-mix"-Variante (Studio + echtes Lagerfoto), wird diese gezeigt
  let heroImage = featured[0] ? featured[0].image : '';
  if (heroImage) { const mix = heroImage.slice(0, heroImage.lastIndexOf('.')) + '-mix.jpg'; if (require('fs').existsSync(require('path').join(__dirname, '..', 'public', 'img', 'products', mix))) heroImage = mix; }
  const palettes = db.prepare(`SELECT * FROM products WHERE ${WITH_IMG} AND product_group = 'palette' ORDER BY sort_order, id LIMIT 6`).all();
  const used = db.prepare(`SELECT * FROM products WHERE ${WITH_IMG} AND product_group = 'gebraucht' ORDER BY sort_order, id LIMIT 3`).all();
  ratings.decorateAll(featured); ratings.decorateAll(palettes); ratings.decorateAll(used);
  const groups = {};
  try { db.prepare(`SELECT product_group AS g, COUNT(*) AS n, MIN(price_cents) AS min FROM products WHERE ${WITH_IMG} GROUP BY product_group`).all().forEach(r => { groups[r.g] = { n: r.n, min: r.min }; }); } catch (e) {}
  res.render('index', {
    title: 'Gitterboxen & EU-Paletten direkt ab Lager – neu und geprüft gebraucht',
    metaDesc: 'DB-Gitterboxen nach DIN 15155 / UIC 435-3 und EU-Paletten direkt ab Lager: fabrikneu oder geprüft gebraucht, DB-Europool-Boxen mit EPAL-Stempel voll tauschfähig, deutschlandweite Lieferung, Kauf auf Rechnung. Direktpreise ohne Zwischenhandel.',
    featured, heroImage, palettes, used, groups,
  });
});

// ---------- Sortiment ----------
const GROUP_META = {
  gitterbox: { title: 'Neue Gitterboxen', sub: 'Fabrikneue DB-/Euro-Gitterboxen nach DIN 15155/8 und UIC 435-3 – mit halber oder ganzer Klappe, mit Deckel, lackiert oder feuerverzinkt. Die DB-Europool-Box mit EPAL-Stempel ist voll tauschfähig. Sofort ab Lager.', meta: 'Neue DB-/Euro-Gitterboxen kaufen – fabrikneu nach DIN/UIC, DB-Europool-Box EPAL-tauschfähig, Bestpreise, Kauf auf Rechnung, deutschlandweiter Versand.' },
  gebraucht: { title: 'Gebrauchte Gitterboxen', sub: 'Geprüfte Gebrauchtware in Top-Zustand: gesichtet, gereinigt und funktionsgeprüft. Voll einsatzfähig – die DB-Europool-Box mit EPAL-Stempel voll tauschfähig – und deutlich günstiger als Neuware.', meta: 'Geprüft gebrauchte DB-Gitterboxen kaufen – gereinigt, funktionsgeprüft, DB-Europool-Box EPAL-tauschfähig, günstig. Deutschlandweiter Versand.' },
  palette:   { title: 'EU-Paletten', sub: 'Fabrikneue Paletten aus Holz und Kunststoff – EPAL, Einweg, Industrie- und Düsseldorfer Paletten in allen gängigen Maßen.', meta: 'EU-Paletten neu kaufen – EPAL, Einweg, Industrie und Kunststoff. Direkt ab Lager, deutschlandweiter Versand.' },
  zubehoer:  { title: 'Zubehör für Gitterboxen', sub: 'Trennwände zum Einhängen, die Gitterboxzange für müheloses Öffnen der Klappen und Kartentaschen für die Warenkennzeichnung – alles passend zu DIN-Gitterboxen, ab 5 Stück direkt ab Lager.', meta: 'Gitterbox-Zubehör kaufen: Trennwände, Gitterboxzange, Galia-Kartentasche. Passend zu DIN-Gitterboxen, direkt ab Lager, deutschlandweiter Versand.' },
};
router.get('/produkte', (req, res) => {
  const gruppe = brand.groups[req.query.gruppe] ? req.query.gruppe : '';
  const kat = String(req.query.kat || '').trim();
  const q = String(req.query.q || '').trim().slice(0, 80);
  let sql = `SELECT * FROM products WHERE ${WITH_IMG}`; const args = [];
  if (q) { const like = '%' + q.replace(/[%_]/g, ' ') + '%'; sql += ' AND (name LIKE ? OR type LIKE ? OR category LIKE ? OR short_desc LIKE ? OR description LIKE ?)'; for (let i = 0; i < 5; i++) args.push(like); }
  if (gruppe) { sql += ' AND product_group = ?'; args.push(gruppe); }
  if (kat) { sql += ' AND category = ?'; args.push(kat); }
  sql += ' ORDER BY sort_order, id';
  const products = db.prepare(sql).all(...args);
  ratings.decorateAll(products);
  // Kategorien (Filter-Chips) innerhalb der gewaehlten Gruppe
  let cats = [];
  try {
    cats = gruppe
      ? db.prepare(`SELECT category AS c, COUNT(*) AS n FROM products WHERE ${WITH_IMG} AND product_group = ? GROUP BY category ORDER BY MIN(sort_order)`).all(gruppe)
      : [];
  } catch (e) {}
  const gm = GROUP_META[gruppe];
  const title = gm ? gm.title : 'Gesamtes Sortiment';
  const sub = gm ? gm.sub : 'Neue und geprüft gebrauchte Gitterboxen sowie EU-Paletten – direkt ab Lager, deutschlandweit geliefert.';
  const metaDesc = gm ? gm.meta : 'Gitterboxen und EU-Paletten direkt ab Lager – neu und geprüft gebraucht. Bestpreise, Kauf auf Rechnung, deutschlandweiter Versand.';
  res.render('catalog', { title: q ? ('Suche: ' + q) : title, sub, metaDesc, products, gruppe, kat, cats, q });
});

// ---------- Produktseite ----------
router.get('/produkt/:slug', (req, res) => {
  const p = db.prepare('SELECT * FROM products WHERE slug = ?').get(req.params.slug);
  if (!p || (!p.active && !(req.user && req.user.is_admin))) return res.status(404).render('error', { title: 'Nicht gefunden', code: 404, message: 'Produkt nicht gefunden.' });
  p.featureList = h.safeParse(p.features, []);
  try { db.prepare('UPDATE products SET views = views + 1 WHERE id = ?').run(p.id); } catch (e) {}
  ratings.decorate(p);
  const canReview = req.user ? ratings.canReview(req.user.id, p.id) : false;
  const hasReviewed = req.user ? ratings.hasReviewed(req.user.id, p.id) : false;
  const related = db.prepare(`SELECT * FROM products WHERE ${WITH_IMG} AND product_group = ? AND id != ? ORDER BY sort_order, id LIMIT 3`).all(p.product_group, p.id);
  ratings.decorateAll(related);
  const metaDesc = (p.short_desc && p.short_desc.trim()) ? p.short_desc.trim() : (p.name + ' kaufen – direkt ab Lager, deutschlandweiter Versand.');
  const addon = ADDON.hosts.includes(p.slug) ? (db.prepare(`SELECT * FROM products WHERE slug = ? AND active = 1 AND sold_out = 0`).get(ADDON.slug) || null) : null;
  res.render('product', { title: p.name + ' kaufen', metaDesc, p, canReview, hasReviewed, related, addon, addonSetCents: ADDON.setCents });
});

// ---------- Warenkorb ----------
router.get('/warenkorb', (req, res) => {
  const { items, totals } = buildCart(req.session, res.locals.settings);
  res.render('cart', { title: 'Warenkorb', items, totals });
});
router.post('/warenkorb/hinzufuegen', (req, res) => {
  const wantsJson = (req.headers['x-requested-with'] === 'fetch') || (String(req.headers.accept || '').indexOf('application/json') !== -1);
  const fail = (msg) => { if (wantsJson) return sendJson(res, { ok: false, error: msg }); req.flash('error', msg); return res.redirect('back'); };
  const done = (msg) => {
    persistCart(req);
    if (wantsJson) { const sum = cartSummary(req.session); return sendJson(res, { ok: true, message: msg, count: sum.count, totalCents: sum.gross, totalFormatted: h.euro(sum.gross) }); }
    req.flash('cartadd', msg); return res.redirect('back');
  };
  const pid = parseInt(req.body.product_id, 10);
  const qty = Math.max(1, parseInt(req.body.quantity, 10) || 1);
  const p = db.prepare('SELECT id, slug, sold_out, min_order, max_order, color_options FROM products WHERE id = ? AND active = 1').get(pid);
  if (!p) return fail('Artikel nicht gefunden.');
  if (p.sold_out) return fail('Dieser Artikel ist derzeit ausverkauft.');
  const opts = h.safeParse(p.color_options, []);
  let color = null;
  if (opts.length) {
    const chosen = String(req.body.color || '');
    if (opts.indexOf(chosen) === -1) return fail('Bitte wählen Sie zuerst eine Farbe aus.');
    color = chosen;
  }
  const key = color ? (pid + '::' + color) : String(pid);
  const min = (req.user && req.user.min_order_waived) ? 1 : Math.max(1, p.min_order || 1);
  const max = Math.max(min, p.max_order || 200);
  const cur = (req.session.cart[key] && Number(req.session.cart[key].quantity)) || 0;
  const neu = cur + qty;
  if (neu < min) return fail(`Für diesen Artikel gilt eine Mindestbestellmenge von ${min} Stück. Bitte legen Sie mindestens ${min} Stück in den Warenkorb.`);
  if (neu > max) return fail(`Für Mengen über ${max} Stück kontaktieren Sie uns bitte für ein individuelles Angebot – gern über unser Kontaktformular.`);
  req.session.cart[key] = { product_id: pid, color: color, quantity: neu };
  let addonMsg = '';
  if (req.body.addon_trennwand === 'ja' && ADDON.hosts.includes(p.slug)) {
    const tw = db.prepare('SELECT id FROM products WHERE slug = ? AND active = 1 AND sold_out = 0').get(ADDON.slug);
    if (tw) { req.session.cart[ADDON.key] = { product_id: tw.id, quantity: 0, set: true }; syncAddons(req.session); addonMsg = ' Trennwände zum Set-Preis passend dazugelegt.'; }
  }
  return done((color ? `${qty} Stück in ${color} in den Warenkorb gelegt.` : 'Artikel wurde in den Warenkorb gelegt.') + addonMsg);
});
router.post('/warenkorb/aktualisieren', (req, res) => {
  const key = String(req.body.key || '');
  if (key === ADDON.key) {   // Set-Trennwaende: Wunschmenge zwischen 10 und Boxenzahl
    const l = req.session.cart[key]; const q = parseInt(req.body.quantity, 10);
    if (l && q > 0) { l.quantity = q; syncAddons(req.session); if (l.quantity !== q) req.flash('info', `Trennwände im Set: mindestens ${l.min} Stück, höchstens so viele wie tauschfähige Gitterboxen im Warenkorb (${l.max}).`); }
    persistCart(req); return res.redirect('/warenkorb');
  }
  const line = req.session.cart[key];
  let qty = parseInt(req.body.quantity, 10);
  if (line && qty > 0) {
    const p = db.prepare('SELECT min_order, max_order FROM products WHERE id = ?').get(line.product_id);
    const min = (req.user && req.user.min_order_waived) ? 1 : Math.max(1, (p && p.min_order) || 1);
    const max = Math.max(min, (p && p.max_order) || 200);
    if (qty < min) { qty = min; req.flash('info', `Mindestbestellmenge für diesen Artikel: ${min} Stück.`); }
    if (qty > max) { qty = max; req.flash('info', `Für Mengen über ${max} Stück kontaktieren Sie uns bitte direkt.`); }
    req.session.cart[key] = { product_id: line.product_id, color: line.color || null, quantity: qty };
  } else if (line) { delete req.session.cart[key]; }
  syncAddons(req.session);
  persistCart(req);
  res.redirect('/warenkorb');
});
router.post('/warenkorb/entfernen', (req, res) => {
  const key = String(req.body.key || '');
  delete req.session.cart[key];
  syncAddons(req.session);
  persistCart(req);
  res.redirect('/warenkorb');
});

// ---------- Kasse ----------
router.get('/kasse', (req, res) => {
  const { items, totals } = buildCart(req.session, res.locals.settings);
  if (items.length === 0) { req.flash('info', 'Ihr Warenkorb ist leer.'); return res.redirect('/warenkorb'); }
  if (!req.user) { req.session.returnTo = '/kasse'; req.flash('info', 'Bitte melden Sie sich an oder registrieren Sie sich, um die Bestellung abzuschließen.'); return res.redirect('/login'); }
  res.render('checkout', { title: 'Kasse', items, totals, rechnungFrei: !!req.user.invoice_allowed });
});
router.post('/kasse', (req, res) => {
  if (!req.user) return res.redirect('/login');
  const { items, totals } = buildCart(req.session, res.locals.settings);
  if (items.length === 0) return res.redirect('/warenkorb');
  const b = req.body, u = req.user;
  if (!b.agb) { req.flash('error', 'Bitte akzeptieren Sie die AGB und die Datenschutzerklärung.'); return res.redirect('/kasse'); }
  if (b.ship_diff === 'ja' && (!(b.ship_street || '').trim() || !(b.ship_zip || '').trim() || !(b.ship_city || '').trim())) {
    req.flash('error', 'Bitte geben Sie für die abweichende Lieferadresse Straße, PLZ und Ort an.'); return res.redirect('/kasse');
  }
  const taxRate = Number(process.env.SELLER_TAXRATE || 19);
  const shipping = totals.shipping;
  // Firmendaten-Momentaufnahme aus den (im Admin bearbeitbaren) Verkäuferdaten.
  const sInfo = sellerLib.info();
  const info = db.prepare(`INSERT INTO orders (
      order_number, user_id, status, cust_first_name, cust_last_name, cust_company, cust_email, cust_phone,
      cust_street, cust_zip, cust_city, cust_country, customer_note, subtotal_cents, tax_rate, shipping_cents,
      seller_name, seller_address, seller_email, seller_phone, seller_iban, seller_bic, seller_bank, seller_ustid,
      payment_days, delivery_days) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`).run(
    'TEMP', u.id, 'neu',
    b.first_name || u.first_name, b.last_name || u.last_name, b.company || u.company || '',
    b.email || u.email, b.phone || u.phone || '',
    b.street || u.street || '', b.zip || u.zip || '', b.city || u.city || '', b.country || u.country || 'Deutschland',
    b.note || '', totals.subtotal, taxRate, shipping,
    sInfo.name || '', sInfo.address || '', sInfo.email || '', sInfo.phone || '',
    process.env.SELLER_IBAN || '', process.env.SELLER_BIC || '', process.env.SELLER_BANK || '', sInfo.ustid || '',
    process.env.PAYMENT_DAYS || '14', process.env.DELIVERY_DAYS || brand.deliveryDaysDefault);
  const orderId = info.lastInsertRowid;
  const orderNo = ids.uniqueOrderNumber();
  db.prepare('UPDATE orders SET order_number = ? WHERE id = ?').run(orderNo, orderId);
  db.prepare('UPDATE orders SET ip = ? WHERE id = ?').run(geo.clientIp(req) || '', orderId);
  try {
    db.prepare('UPDATE orders SET cust_customer_type = ?, cust_ustid = ? WHERE id = ?')
      .run(u.customer_type || 'firma', (u.customer_type === 'firma') ? (u.ustid || '') : '', orderId);
  } catch (e) { console.error('Snapshot Firma/USt-IdNr:', e.message); }
  try { db.prepare('UPDATE orders SET seller_taxnumber = ? WHERE id = ?').run(process.env.SELLER_TAXNUMBER || '', orderId); } catch (e) {}
  const pm = (req.body.payment_method === 'rechnung' && u.invoice_allowed) ? 'rechnung' : 'vorkasse';
  db.prepare('UPDATE orders SET payment_method = ? WHERE id = ?').run(pm, orderId);
  if (b.ship_diff === 'ja' && (b.ship_street || '').trim()) {
    try {
      db.prepare('UPDATE orders SET ship_first_name=?, ship_last_name=?, ship_company=?, ship_street=?, ship_zip=?, ship_city=?, ship_country=? WHERE id=?')
        .run(b.ship_first_name || '', b.ship_last_name || '', b.ship_company || '', b.ship_street || '', b.ship_zip || '', b.ship_city || '', b.ship_country || 'Deutschland', orderId);
    } catch (e) { console.error('Snapshot Lieferadresse:', e.message); }
  }
  const insItem = db.prepare('INSERT INTO order_items (order_id, product_id, name, type, unit_cents, quantity) VALUES (?,?,?,?,?,?)');
  const tx = db.transaction(() => { for (const it of items) insItem.run(orderId, it.id, it.name + (it.color ? ' – Farbe: ' + it.color : ''), it.type, it.unit_cents, it.quantity); });
  tx();
  try { inventory.decrementForItems(items); } catch (e) { console.error('Bestand abbuchen:', e.message); }
  db.prepare('UPDATE users SET first_name=?, last_name=?, company=?, street=?, zip=?, city=?, country=?, phone=? WHERE id=?')
    .run(b.first_name || u.first_name, b.last_name || u.last_name, b.company || u.company || '', b.street || u.street || '',
         b.zip || u.zip || '', b.city || u.city || '', b.country || u.country || 'Deutschland', b.phone || u.phone || '', u.id);
  const order = db.prepare('SELECT * FROM orders WHERE id = ?').get(orderId);
  const mail = emails.orderConfirmation(order, items);
  sendMail({ to: order.cust_email, subject: mail.subject, html: mail.html, text: mail.text }).catch(err => console.error('Mailfehler (Bestätigung):', err.message));
  req.session.cart = {};
  cart.clearUserCart(u.id);
  res.redirect('/bestellung/' + orderNo);
});
router.get('/bestellung/:nr', (req, res) => {
  const order = db.prepare('SELECT * FROM orders WHERE order_number = ?').get(req.params.nr);
  if (!order) return res.status(404).render('error', { title: 'Nicht gefunden', code: 404, message: 'Bestellung nicht gefunden.' });
  if (!req.user || (req.user.id !== order.user_id && !req.user.is_admin)) return res.status(403).render('error', { title: 'Kein Zugriff', code: 403, message: 'Diese Bestellung gehört nicht zu Ihrem Konto.' });
  const items = db.prepare('SELECT * FROM order_items WHERE order_id = ?').all(order.id);
  res.render('order-confirmation', { title: 'Bestellung ' + order.order_number, order, items, totals: h.totals(items, order.tax_rate, order.shipping_cents) });
});

// ---------- Kontakt & Infoseiten ----------
router.get('/kontakt', (req, res) => res.render('contact', { title: 'Kontakt & Angebotsanfrage' }));
router.post('/kontakt', async (req, res) => {
  const esc = (v) => String(v == null ? '' : v).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  const name = String(req.body.name || '').trim();
  const email = String(req.body.email || '').trim();
  const message = String(req.body.message || '').trim();
  if (!name || !email || !message) { req.flash('error', 'Bitte füllen Sie alle Felder aus.'); return res.redirect('/kontakt'); }
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) { req.flash('error', 'Bitte geben Sie eine gültige E-Mail-Adresse an.'); return res.redirect('/kontakt'); }
  const sInfo = sellerLib.info();
  const to = sInfo.email || process.env.SELLER_EMAIL || process.env.ADMIN_EMAIL || '';
  const subject = `Kontaktanfrage von ${name}`;
  const text = `Neue Kontaktanfrage über ${sInfo.brand}\n\nName: ${name}\nE-Mail: ${email}\n\nNachricht:\n${message}\n`;
  const html = `<h2 style="font-family:Arial;color:${brand.mail.ink}">Neue Kontaktanfrage</h2><p style="font-family:Arial"><b>Name:</b> ${esc(name)}<br><b>E-Mail:</b> ${esc(email)}</p><p style="font-family:Arial;white-space:pre-wrap;border-left:3px solid ${brand.mail.accent};padding-left:12px">${esc(message)}</p>`;
  try { await sendMail({ to, subject, text, html, replyTo: email }); }
  catch (e) { console.error('Kontakt-Mail-Fehler:', e.message); }
  req.flash('success', 'Vielen Dank! Ihre Nachricht wurde gesendet – wir melden uns zügig bei Ihnen.');
  res.redirect('/kontakt');
});
router.get('/karriere', (req, res) => res.render('karriere', { title: 'Karriere – Lagermitarbeiter (m/w/d)' }));
router.get('/agb', (req, res) => res.render('agb', { title: 'AGB' }));
router.get('/datenschutz', (req, res) => res.render('datenschutz', { title: 'Datenschutz' }));
router.get('/impressum', (req, res) => res.render('impressum', { title: 'Impressum' }));

// ---------- Bewertung ----------
router.post('/produkt/:slug/bewerten', (req, res) => {
  const p = db.prepare('SELECT id, slug FROM products WHERE slug = ?').get(req.params.slug);
  if (!p) return res.status(404).render('error', { title: 'Nicht gefunden', code: 404, message: 'Produkt nicht gefunden.' });
  if (!req.user) { req.session.returnTo = '/produkt/' + p.slug; req.flash('info', 'Bitte melden Sie sich an, um zu bewerten.'); return res.redirect('/login'); }
  const rating = parseInt(req.body.rating, 10);
  if (!(rating >= 1 && rating <= 5)) { req.flash('error', 'Bitte eine Bewertung von 1 bis 5 Sternen wählen.'); return res.redirect('/produkt/' + p.slug); }
  if (!ratings.canReview(req.user.id, p.id)) { req.flash('error', 'Sie können dieses Produkt erst bewerten, nachdem Sie es gekauft und erhalten haben.'); return res.redirect('/produkt/' + p.slug); }
  if (ratings.hasReviewed(req.user.id, p.id)) { req.flash('info', 'Sie haben dieses Produkt bereits bewertet.'); return res.redirect('/produkt/' + p.slug); }
  db.prepare('INSERT INTO reviews (product_id, user_id, rating) VALUES (?,?,?)').run(p.id, req.user.id, rating);
  req.flash('success', 'Vielen Dank für Ihre Bewertung!');
  res.redirect('/produkt/' + p.slug);
});

module.exports = router;
