﻿# Erzeugt alle Gitterbox-Produktbilder im Studio-Look aus den weissen Originalfotos (_bilder-original-weiss).
# Aufruf: Rechtsklick -> Mit PowerShell ausfuehren  (oder: powershell -ExecutionPolicy Bypass -File tools\bilder-studio-look.ps1)
param(
  [string]$SrcDir = (Join-Path $PSScriptRoot "..\_bilder-original-weiss"),
  [string]$OutDir = (Join-Path $PSScriptRoot "..\public\img\products"),
  [string]$Only = ""
)
Add-Type -AssemblyName System.Drawing
$src = @"
using System; using System.Drawing; using System.Drawing.Drawing2D; using System.Drawing.Imaging; using System.Runtime.InteropServices;
public class Style {
  public double[] Top = new double[] {251,250,247};
  public double[] Bottom = new double[] {231,229,222};
  public double Spot = 5;        // Aufhellung um das Objekt
  public double Vignette = 9;    // Abdunklung in den Ecken
  public double Shadow = 0.26;   // Kontaktschatten (Kern)
  public double Ambient = 0.09;  // weicher, breiter Schatten
}
public static class Restyle {
  static double Clamp(double v, double lo, double hi) { return v < lo ? lo : (v > hi ? hi : v); }
  static double Bump(double e) { if (e >= 1) return 0; double t = 1 - e * e; return t * t; }

  // Freistellen gegen Weiss: liefert premultiplied ARGB-Bitmap + Bounding-Box (alpha > 0.5)
  public static Bitmap Cutout(string path, double a0, double a1, out Rectangle bbox) {
    using (Bitmap b = new Bitmap(path)) {
      int w = b.Width, h = b.Height;
      BitmapData d = b.LockBits(new Rectangle(0,0,w,h), ImageLockMode.ReadOnly, PixelFormat.Format24bppRgb);
      byte[] buf = new byte[d.Stride * h]; Marshal.Copy(d.Scan0, buf, 0, buf.Length); b.UnlockBits(d);
      Bitmap outB = new Bitmap(w, h, PixelFormat.Format32bppPArgb);
      BitmapData od = outB.LockBits(new Rectangle(0,0,w,h), ImageLockMode.WriteOnly, PixelFormat.Format32bppPArgb);
      byte[] ob = new byte[od.Stride * h];
      int minX = w, minY = h, maxX = -1, maxY = -1;
      for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) {
        int i = y * d.Stride + x * 3; int o = y * od.Stride + x * 4;
        int bb = buf[i], gg = buf[i+1], rr = buf[i+2];
        int mn = Math.Min(bb, Math.Min(gg, rr));
        double dd = 255 - mn;
        double a = Clamp((dd - a0) / (a1 - a0), 0, 1);
        if (a <= 0) { ob[o] = 0; ob[o+1] = 0; ob[o+2] = 0; ob[o+3] = 0; continue; }
        // Entmischen gegen Weiss, direkt premultiplied: P = I - (1-a)*255
        double k = (a - 1) * 255;
        ob[o]   = (byte)Clamp(bb + k, 0, 255);
        ob[o+1] = (byte)Clamp(gg + k, 0, 255);
        ob[o+2] = (byte)Clamp(rr + k, 0, 255);
        ob[o+3] = (byte)Math.Round(a * 255);
        if (a > 0.5) { if (x < minX) minX = x; if (x > maxX) maxX = x; if (y < minY) minY = y; if (y > maxY) maxY = y; }
      }
      Marshal.Copy(ob, 0, od.Scan0, ob.Length); outB.UnlockBits(od);
      bbox = (maxX < 0) ? new Rectangle(0,0,w,h) : new Rectangle(minX, minY, maxX - minX + 1, maxY - minY + 1);
      return outB;
    }
  }

  // Studio-Hintergrund: Verlauf + Spot + Vignette + Schatten unter dem Objekt
  public static Bitmap Backdrop(int W, int H, Style st, double cx, double objBottom, double bw, double bh) {
    Bitmap bmp = new Bitmap(W, H, PixelFormat.Format24bppRgb);
    BitmapData d = bmp.LockBits(new Rectangle(0,0,W,H), ImageLockMode.WriteOnly, PixelFormat.Format24bppRgb);
    byte[] buf = new byte[d.Stride * H];
    double spotX = W * 0.5, spotY = H * 0.42, spotR = Math.Max(W, H) * 0.62;
    double vx = W * 0.5, vy = H * 0.5, vr = Math.Sqrt(vx*vx + vy*vy);
    double sy = objBottom - bh * 0.015, rx = bw * 0.5 + 8, ry = Math.Max(22, bh * 0.07);
    double rx2 = bw * 0.62, ry2 = Math.Max(40, bh * 0.17);
    for (int y = 0; y < H; y++) {
      double t = (double)y / (H - 1);
      for (int x = 0; x < W; x++) {
        double dxs = (x - spotX) / spotR, dys = (y - spotY) / spotR;
        double spot = st.Spot * Bump(Math.Sqrt(dxs*dxs + dys*dys));
        double dv = Math.Sqrt((x-vx)*(x-vx) + (y-vy)*(y-vy)) / vr;
        double vig = st.Vignette * dv * dv;
        double ex = (x - cx) / rx, ey = (y - sy) / ry; double e = Math.Sqrt(ex*ex + ey*ey);
        double ex2 = (x - cx) / rx2, ey2 = (y - sy) / ry2; double e2 = Math.Sqrt(ex2*ex2 + ey2*ey2);
        double f = 1 - st.Shadow * Bump(e) - st.Ambient * Bump(e2);
        int i = y * d.Stride + x * 3;
        for (int c = 0; c < 3; c++) {
          double v = st.Top[c] + (st.Bottom[c] - st.Top[c]) * t + spot - vig;
          v = Clamp(v * f, 0, 255);
          buf[i + (2 - c)] = (byte)Math.Round(v);
        }
      }
    }
    Marshal.Copy(buf, 0, d.Scan0, buf.Length); bmp.UnlockBits(d);
    return bmp;
  }

  public static void SaveJpeg(Bitmap b, string path, long quality) {
    ImageCodecInfo codec = null;
    foreach (ImageCodecInfo c in ImageCodecInfo.GetImageEncoders()) if (c.MimeType == "image/jpeg") codec = c;
    EncoderParameters ep = new EncoderParameters(1);
    ep.Param[0] = new EncoderParameter(System.Drawing.Imaging.Encoder.Quality, quality);
    b.Save(path, codec, ep);
  }

  // Objekt mittig auf (cx, cy) mit Skalierung; maxH/maxW begrenzen die Objektgroesse
  public static string Process(string src, string dst, Style st, int W, int H, double cx, double cy, double maxW, double maxH, long quality) {
    Rectangle bb;
    using (Bitmap cut = Cutout(src, 10, 34, out bb)) {
      double s = Math.Min(1.0, Math.Min(maxW / bb.Width, maxH / bb.Height));
      double bw = bb.Width * s, bh = bb.Height * s;
      double objBottom = cy + bh / 2;
      using (Bitmap bg = Backdrop(W, H, st, cx, objBottom, bw, bh)) {
        using (Graphics g = Graphics.FromImage(bg)) {
          g.InterpolationMode = InterpolationMode.HighQualityBicubic;
          g.SmoothingMode = SmoothingMode.HighQuality;
          g.PixelOffsetMode = PixelOffsetMode.HighQuality;
          g.CompositingQuality = CompositingQuality.HighQuality;
          g.CompositingMode = CompositingMode.SourceOver;
          using (ImageAttributes ia = new ImageAttributes()) {
            ia.SetWrapMode(WrapMode.TileFlipXY);
            float dx = (float)(cx - (bb.X + bb.Width / 2.0) * s), dy = (float)(cy - (bb.Y + bb.Height / 2.0) * s);
            RectangleF dest = new RectangleF(dx, dy, (float)(cut.Width * s), (float)(cut.Height * s));
            g.DrawImage(cut, Rectangle.Round(dest), 0, 0, cut.Width, cut.Height, GraphicsUnit.Pixel, ia);
          }
        }
        SaveJpeg(bg, dst, quality);
      }
      return string.Format("{0}x{1} -> {2}x{3} @ {4:0.00}", bb.Width, bb.Height, Math.Round(bw), Math.Round(bh), s);
    }
  }
}
"@
Add-Type -TypeDefinition $src -ReferencedAssemblies System.Drawing

$neu = New-Object Style
$gebraucht = New-Object Style
$gebraucht.Top = @(247.0, 245.0, 240.0); $gebraucht.Bottom = @(224.0, 221.0, 213.0)

# Ziel-Datei -> Quell-Datei (weisses Original), Stil
$map = @()
Get-ChildItem $SrcDir -Filter *.jpg | Where-Object { $_.Name -notlike "faltbare*" } | ForEach-Object { $map += ,@($_.Name, $_.Name, "neu") }
foreach ($base in @("db-europool-gitterbox-halbe-klappe", "euro-gitterbox-mit-deckel")) {
  foreach ($suf in @("", "-2", "-3")) { $map += ,@("$base-gebraucht$suf.jpg", "$base$suf.jpg", "gebraucht") }
}
New-Item -ItemType Directory -Force $OutDir | Out-Null
$sw = [System.Diagnostics.Stopwatch]::StartNew()
foreach ($m in $map) {
  if ($Only -and $m[0] -notlike "*$Only*") { continue }
  $st = if ($m[2] -eq "gebraucht") { $gebraucht } else { $neu }
  $info = [Restyle]::Process((Join-Path $SrcDir $m[1]), (Join-Path $OutDir $m[0]), $st, 1000, 1000, 500.0, 492.0, 860.0, 690.0, 90)
  "{0,-52} {1,-10} {2}" -f $m[0], $m[2], $info
}
if (-not $Only) {
  $info = [Restyle]::Process((Join-Path $SrcDir "db-europool-gitterbox-halbe-klappe.jpg"), (Join-Path $PSScriptRoot "og-basis.jpg"), $neu, 1200, 630, 815.0, 318.0, 600.0, 470.0, 88)
  "{0,-52} {1,-10} {2}" -f "og-basis.jpg (Basis fuer og-image)", "neu", $info
}
"Fertig in {0:0.0} s" -f $sw.Elapsed.TotalSeconds
