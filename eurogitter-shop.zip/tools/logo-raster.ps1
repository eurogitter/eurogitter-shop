# Rastert Logo-Geometrie (Polygone aus lib/logo.js) zu PNG/JPG – wird von tools/logo-build.js aufgerufen.
# Auftragsdatei: Tab-getrennte Zeilen  J (neues Bild)  S (Versatz/Skalierung)  P (Polygon)
param([Parameter(Mandatory=$true)][string]$Jobs)
Add-Type -AssemblyName System.Drawing
$src = @'
using System; using System.IO; using System.Drawing; using System.Drawing.Drawing2D; using System.Drawing.Imaging; using System.Collections.Generic; using System.Globalization;
public static class LogoRaster {
  static float F(string s) { return float.Parse(s, CultureInfo.InvariantCulture); }
  static Color C(string hex) { hex = hex.TrimStart('#'); return Color.FromArgb(255, Convert.ToInt32(hex.Substring(0,2),16), Convert.ToInt32(hex.Substring(2,2),16), Convert.ToInt32(hex.Substring(4,2),16)); }
  static Dictionary<string,string> KV(string[] tok) { var d = new Dictionary<string,string>(); for (int i = 1; i < tok.Length; i++) { int p = tok[i].IndexOf('='); if (p > 0) d[tok[i].Substring(0,p)] = tok[i].Substring(p+1); } return d; }
  static void Save(Bitmap b, string path, string fmt, long q) {
    Directory.CreateDirectory(Path.GetDirectoryName(path));
    if (fmt == "jpg") {
      ImageCodecInfo codec = null; foreach (ImageCodecInfo c in ImageCodecInfo.GetImageEncoders()) if (c.MimeType == "image/jpeg") codec = c;
      EncoderParameters ep = new EncoderParameters(1); ep.Param[0] = new EncoderParameter(System.Drawing.Imaging.Encoder.Quality, q);
      using (Bitmap flat = new Bitmap(b.Width, b.Height, PixelFormat.Format24bppRgb)) {
        using (Graphics g = Graphics.FromImage(flat)) { g.Clear(Color.White); g.DrawImageUnscaled(b, 0, 0); }
        flat.Save(path, codec, ep);
      }
    } else b.Save(path, ImageFormat.Png);
  }
  public static string Run(string jobsFile) {
    Bitmap bmp = null; Graphics g = null; string outPath = null, fmt = "png"; long q = 90; float ox = 0, oy = 0, sc = 1; int count = 0;
    foreach (string raw in File.ReadAllLines(jobsFile)) {
      if (raw.Trim().Length == 0) continue;
      string[] tok = raw.Split('\t');
      if (tok[0] == "J") {
        if (bmp != null) { g.Dispose(); Save(bmp, outPath, fmt, q); bmp.Dispose(); count++; }
        var kv = KV(tok); outPath = kv["out"]; int w = int.Parse(kv["w"]), h = int.Parse(kv["h"]);
        fmt = kv.ContainsKey("fmt") ? kv["fmt"] : "png"; q = kv.ContainsKey("q") ? long.Parse(kv["q"]) : 90;
        bmp = new Bitmap(w, h, PixelFormat.Format32bppArgb); g = Graphics.FromImage(bmp);
        g.SmoothingMode = SmoothingMode.AntiAlias; g.PixelOffsetMode = PixelOffsetMode.HighQuality; g.CompositingQuality = CompositingQuality.HighQuality; g.InterpolationMode = InterpolationMode.HighQualityBicubic;
        if (kv.ContainsKey("bg") && kv["bg"] != "none") g.Clear(C(kv["bg"])); else g.Clear(Color.Transparent);
        if (kv.ContainsKey("img")) { using (MemoryStream ms = new MemoryStream(File.ReadAllBytes(kv["img"]))) { using (Image im = Image.FromStream(ms)) { g.DrawImage(im, new Rectangle(0, 0, w, h)); } } }
        ox = 0; oy = 0; sc = 1;
      } else if (tok[0] == "S") { var kv = KV(tok); ox = F(kv["x"]); oy = F(kv["y"]); sc = F(kv["s"]); }
      else if (tok[0] == "P") {
        var kv = KV(tok); string[] pts = kv["pts"].Split(';'); PointF[] P = new PointF[pts.Length];
        for (int i = 0; i < pts.Length; i++) { string[] xy = pts[i].Split(','); P[i] = new PointF(ox + F(xy[0]) * sc, oy + F(xy[1]) * sc); }
        bool closed = kv["c"] == "1";
        if (kv["f"] != "-" && P.Length >= 3) { using (SolidBrush br = new SolidBrush(C(kv["f"]))) { g.FillPolygon(br, P); } }
        if (kv["s"] != "-") {
          using (Pen pen = new Pen(C(kv["s"]), F(kv["w"]) * sc)) {
            bool rc = !kv.ContainsKey("cap") || kv["cap"] != "butt";
            pen.LineJoin = LineJoin.Round; pen.StartCap = rc ? LineCap.Round : LineCap.Flat; pen.EndCap = rc ? LineCap.Round : LineCap.Flat;
            if (closed && P.Length >= 3) g.DrawPolygon(pen, P); else if (P.Length >= 2) g.DrawLines(pen, P);
          }
        }
      }
    }
    if (bmp != null) { g.Dispose(); Save(bmp, outPath, fmt, q); bmp.Dispose(); count++; }
    return count.ToString();
  }
}
'@
Add-Type -TypeDefinition $src -ReferencedAssemblies System.Drawing
Write-Output ([LogoRaster]::Run($Jobs))
