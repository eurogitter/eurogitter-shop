// Erzeugt drei Logo-Entwuerfe fuer den Gitterbox-Shop als reine Vektorgrafik (keine Schrift-Abhaengigkeit):
// alle Buchstaben werden aus eigenen Alphabeten gebaut (Monolinie + Raster), damit Vorschau = Endergebnis.
const fs = require('fs');
const path = require('path');
const OUT = process.argv[2] || 'C:/Users/Administrator/Desktop/1/_logo-entwuerfe';
fs.mkdirSync(OUT, { recursive: true });

// ---------- Monolinie-Alphabet (Versalhoehe 14, y nach unten, Skelettlinien) ----------
const MONO = {
  A: { w: 10, d: 'M0,14 L5,0 L10,14 M1.8,9 L8.2,9' },
  B: { w: 9,  d: 'M0,14 L0,0 L5,0 A3.5,3.5 0 0 1 5,7 L0,7 L5.5,7 A3.5,3.5 0 0 1 5.5,14 L0,14' },
  C: { w: 10, d: 'M8.2,1.6 A5,7 0 1 0 8.2,12.4' },
  D: { w: 9,  d: 'M0,14 L0,0 L4,0 A5,7 0 0 1 4,14 L0,14' },
  E: { w: 8,  d: 'M8,0 L0,0 L0,14 L8,14 M0,7 L7,7' },
  F: { w: 8,  d: 'M8,0 L0,0 L0,14 M0,7 L6.5,7' },
  G: { w: 10, d: 'M8.2,1.6 A5,7 0 1 0 10,7 L5.5,7' },
  H: { w: 10, d: 'M0,0 L0,14 M10,0 L10,14 M0,7 L10,7' },
  I: { w: 0,  d: 'M0,0 L0,14' },
  J: { w: 8,  d: 'M8,0 L8,10 A4,4 0 0 1 0,10' },
  K: { w: 9,  d: 'M0,0 L0,14 M9,0 L0,8.5 M3,5.7 L9,14' },
  L: { w: 8,  d: 'M0,0 L0,14 L8,14' },
  M: { w: 12, d: 'M0,14 L0,0 L6,9 L12,0 L12,14' },
  N: { w: 10, d: 'M0,14 L0,0 L10,14 L10,0' },
  O: { w: 10, d: 'M5,0 A5,7 0 1 1 5,14 A5,7 0 1 1 5,0' },
  P: { w: 9,  d: 'M0,14 L0,0 L5,0 A3.75,3.75 0 0 1 5,7.5 L0,7.5' },
  Q: { w: 10, d: 'M5,0 A5,7 0 1 1 5,14 A5,7 0 1 1 5,0 M6.5,10.5 L10.5,14.5' },
  R: { w: 9,  d: 'M0,14 L0,0 L5,0 A3.75,3.75 0 0 1 5,7.5 L0,7.5 M4.5,7.5 L9,14' },
  S: { w: 9,  d: 'M7.2,1.3 A3.5,3.5 0 1 0 4.5,7 A3.5,3.5 0 1 1 1.8,12.7' },
  T: { w: 10, d: 'M0,0 L10,0 M5,0 L5,14' },
  U: { w: 10, d: 'M0,0 L0,9 A5,5 0 0 0 10,9 L10,0' },
  V: { w: 10, d: 'M0,0 L5,14 L10,0' },
  W: { w: 14, d: 'M0,0 L3.5,14 L7,3 L10.5,14 L14,0' },
  X: { w: 10, d: 'M0,0 L10,14 M10,0 L0,14' },
  Y: { w: 10, d: 'M0,0 L5,7.5 L10,0 M5,7.5 L5,14' },
  Z: { w: 10, d: 'M0,0 L10,0 L0,14 L10,14' },
  ' ': { w: 4, d: '' },
  '-': { w: 6, d: 'M0,7 L6,7' },
  '.': { w: 0, d: 'M0,14 L0,13.9' },
  '·': { w: 0, d: 'M0,7 L0,6.9' },
  '&': { w: 10, d: 'M10,14 L2,4 A3,3 0 1 1 7,4 L1.5,9.5 A3.2,3.2 0 0 0 6.5,13.5 L10,9' },
  '0': { w: 10, d: 'M5,0 A5,7 0 1 1 5,14 A5,7 0 1 1 5,0' },
  '1': { w: 5, d: 'M0,3.5 L4.5,0 L4.5,14' },
  '2': { w: 9, d: 'M0.5,3.8 A4.5,4 0 1 1 7.5,6.8 L0,14 L9,14' },
  '3': { w: 9, d: 'M0.8,1.6 A3.5,3.5 0 1 1 4.5,7 A3.5,3.5 0 1 1 0.8,12.4' },
  '4': { w: 10, d: 'M7,14 L7,0 L0,10 L10,10' },
  '5': { w: 9, d: 'M8.5,0 L1,0 L0.5,6.5 L4.5,5.8 A4.1,4.1 0 1 1 0.8,12.5' },
  '6': { w: 10, d: 'M7.5,0 L2.5,6 A4.6,4.6 0 1 0 9.2,9.4' },
  '7': { w: 9, d: 'M0,0 L9,0 L3,14' },
  '8': { w: 9, d: 'M4.5,7 A3.3,3.3 0 1 1 4.5,0.4 A3.3,3.3 0 1 1 4.5,7 A3.5,3.5 0 1 0 4.5,14 A3.5,3.5 0 1 0 4.5,7' },
  '9': { w: 10, d: 'M2.5,14 L7.5,8 A4.6,4.6 0 1 0 0.8,4.6' }
};
MONO['Ä'] = { w: 10, d: MONO.A.d + ' M2.5,-3.4 L2.5,-3.3 M7.5,-3.4 L7.5,-3.3' };
MONO['Ö'] = { w: 10, d: MONO.O.d + ' M2.5,-3.4 L2.5,-3.3 M7.5,-3.4 L7.5,-3.3' };
MONO['Ü'] = { w: 10, d: MONO.U.d + ' M2.5,-3.4 L2.5,-3.3 M7.5,-3.4 L7.5,-3.3' };

// Monolinie-Schriftzug. size = Versalhoehe in px, stroke in Skelett-Einheiten (14 = Versalhoehe)
function monoWord(text, o) {
  const s = o.size / 14, stroke = o.stroke || 2.2, sp = o.spacing == null ? 5 : o.spacing;
  let x = 0; const parts = [];
  for (const ch of String(text).toUpperCase()) {
    const g = MONO[ch]; if (!g) { console.warn('Monolinie: kein Glyph fuer', ch); continue; }
    if (g.d) parts.push('<path transform="translate(' + x + ',0)" d="' + g.d + '"/>');
    x += g.w + sp;
  }
  const width = (x - sp) * s;
  const svg = '<g transform="translate(' + (o.x || 0) + ',' + (o.y || 0) + ') scale(' + s + ')" fill="none" stroke="' + o.color + '" stroke-width="' + stroke + '" stroke-linecap="round" stroke-linejoin="round">' + parts.join('') + '</g>';
  return { svg, width, height: 14 * s, pad: stroke * s / 2 };
}
// Monolinie-Schriftzug auf einem Kreisbogen (fuer das Siegel). top=true: oben, Schrift nach aussen; sonst unten, aufrecht lesbar
function monoArc(text, o) {
  const s = o.size / 14, stroke = o.stroke || 2.2, sp = o.spacing == null ? 5 : o.spacing;
  const glyphs = []; let total = 0;
  for (const ch of String(text).toUpperCase()) { const g = MONO[ch]; if (!g) continue; glyphs.push(g); total += g.w + sp; }
  total -= sp;
  const rMid = o.r + 7 * s; // Mitte der Schrift-Ringzone (Grundlinie bei o.r)
  let cum = 0; const parts = [];
  for (const g of glyphs) {
    const along = (cum + g.w / 2) * s;                          // Position der Glyphmitte entlang des Bogens
    const off = along - total * s / 2;                          // relativ zur Textmitte
    const deg = (off / rMid) * 180 / Math.PI;
    const phi = o.top ? o.center + deg : o.center - deg;
    const tr = o.top
      ? 'rotate(' + phi.toFixed(3) + ') translate(' + (-g.w * s / 2) + ',' + (-o.r - 14 * s) + ') scale(' + s + ')'
      : 'rotate(' + phi.toFixed(3) + ') translate(0,' + (-o.r) + ') rotate(180) translate(' + (-g.w * s / 2) + ',0) scale(' + s + ')';
    if (g.d) parts.push('<path transform="' + tr + '" d="' + g.d + '"/>');
    cum += g.w + sp;
  }
  return '<g transform="translate(' + o.cx + ',' + o.cy + ')" fill="none" stroke="' + o.color + '" stroke-width="' + stroke + '" stroke-linecap="round" stroke-linejoin="round">' + parts.join('') + '</g>';
}

// ---------- Raster-Alphabet (5x7 Bloecke) ----------
const BLOCK = {
  A: ['.###.', '#...#', '#...#', '#####', '#...#', '#...#', '#...#'],
  B: ['####.', '#...#', '#...#', '####.', '#...#', '#...#', '####.'],
  C: ['.####', '#....', '#....', '#....', '#....', '#....', '.####'],
  D: ['####.', '#...#', '#...#', '#...#', '#...#', '#...#', '####.'],
  E: ['#####', '#....', '#....', '####.', '#....', '#....', '#####'],
  F: ['#####', '#....', '#....', '####.', '#....', '#....', '#....'],
  G: ['.####', '#....', '#....', '#.###', '#...#', '#...#', '.####'],
  H: ['#...#', '#...#', '#...#', '#####', '#...#', '#...#', '#...#'],
  I: ['#', '#', '#', '#', '#', '#', '#'],
  J: ['....#', '....#', '....#', '....#', '#...#', '#...#', '.###.'],
  K: ['#...#', '#..#.', '#.#..', '##...', '#.#..', '#..#.', '#...#'],
  L: ['#....', '#....', '#....', '#....', '#....', '#....', '#####'],
  M: ['#...#', '##.##', '#.#.#', '#.#.#', '#...#', '#...#', '#...#'],
  N: ['#...#', '##..#', '#.#.#', '#..##', '#...#', '#...#', '#...#'],
  O: ['.###.', '#...#', '#...#', '#...#', '#...#', '#...#', '.###.'],
  P: ['####.', '#...#', '#...#', '####.', '#....', '#....', '#....'],
  Q: ['.###.', '#...#', '#...#', '#...#', '#.#.#', '#..#.', '.##.#'],
  R: ['####.', '#...#', '#...#', '####.', '#.#..', '#..#.', '#...#'],
  S: ['.####', '#....', '#....', '.###.', '....#', '....#', '####.'],
  T: ['#####', '..#..', '..#..', '..#..', '..#..', '..#..', '..#..'],
  U: ['#...#', '#...#', '#...#', '#...#', '#...#', '#...#', '.###.'],
  V: ['#...#', '#...#', '#...#', '#...#', '#...#', '.#.#.', '..#..'],
  W: ['#...#', '#...#', '#...#', '#.#.#', '#.#.#', '#.#.#', '.#.#.'],
  X: ['#...#', '#...#', '.#.#.', '..#..', '.#.#.', '#...#', '#...#'],
  Y: ['#...#', '#...#', '.#.#.', '..#..', '..#..', '..#..', '..#..'],
  Z: ['#####', '....#', '...#.', '..#..', '.#...', '#....', '#####'],
  ' ': ['...', '...', '...', '...', '...', '...', '...'],
  '-': ['.....', '.....', '.....', '#####', '.....', '.....', '.....'],
  '.': ['.', '.', '.', '.', '.', '.', '#'],
  '0': ['.###.', '#...#', '#..##', '#.#.#', '##..#', '#...#', '.###.'],
  '1': ['..#..', '.##..', '..#..', '..#..', '..#..', '..#..', '.###.'],
  '2': ['.###.', '#...#', '....#', '...#.', '..#..', '.#...', '#####'],
  '3': ['####.', '....#', '....#', '.###.', '....#', '....#', '####.'],
  '4': ['...#.', '..##.', '.#.#.', '#..#.', '#####', '...#.', '...#.'],
  '5': ['#####', '#....', '####.', '....#', '....#', '#...#', '.###.'],
  '6': ['.###.', '#....', '#....', '####.', '#...#', '#...#', '.###.'],
  '7': ['#####', '....#', '...#.', '..#..', '.#...', '.#...', '.#...'],
  '8': ['.###.', '#...#', '#...#', '.###.', '#...#', '#...#', '.###.'],
  '9': ['.###.', '#...#', '#...#', '.####', '....#', '....#', '.###.']
};
BLOCK['Ä'] = ['#...#', '.....'].concat(BLOCK.A.slice(2)); BLOCK['Ö'] = ['#...#', '.....'].concat(BLOCK.O.slice(2)); BLOCK['Ü'] = ['#...#', '.....'].concat(BLOCK.U.slice(2));
BLOCK['Ä'][2] = '.###.'; BLOCK['Ö'][2] = '.###.';

// Raster-Schriftzug. cell = Blockgroesse, gap = Fuge, letterGap = Abstand zwischen Buchstaben; accent = {letter,row,col,color}
function blockWord(text, o) {
  const c = o.cell, g = o.gap, lg = o.letterGap == null ? c : o.letterGap;
  let x = 0, li = 0; const rects = [];
  for (const ch of String(text).toUpperCase()) {
    const rows = BLOCK[ch]; if (!rows) { console.warn('Raster: kein Glyph fuer', ch); continue; }
    const w = rows[0].length;
    rows.forEach((row, r) => { for (let cc = 0; cc < row.length; cc++) if (row[cc] === '#') {
      const acc = o.accent && o.accent.letter === li && o.accent.row === r && o.accent.col === cc;
      rects.push('<rect x="' + (x + cc * (c + g)).toFixed(2) + '" y="' + (r * (c + g)).toFixed(2) + '" width="' + c + '" height="' + c + '"' + (acc ? ' fill="' + o.accent.color + '"' : '') + '/>');
    } });
    x += w * (c + g) - g + lg; li++;
  }
  const width = x - lg, height = 7 * (c + g) - g;
  return { svg: '<g transform="translate(' + (o.x || 0) + ',' + (o.y || 0) + ')" fill="' + o.color + '">' + rects.join('') + '</g>', width, height };
}

// ---------- Zeichen (Marks) ----------
// 1) Isometrische Drahtgitter-Box, viewBox 0 0 64 64
function markWire(c) {
  const L = 22, D = 16, H = 19, ox = 32, oy = 53;
  const P = (a, b, z) => [ox + a * 0.866 - b * 0.866, oy - a * 0.5 - b * 0.5 - z];
  const pt = (p) => p[0].toFixed(2) + ',' + p[1].toFixed(2);
  const P0 = P(0, 0, 0), P1 = P(L, 0, 0), P2 = P(0, D, 0), P3 = P(L, D, 0);
  const T0 = P(0, 0, H), T1 = P(L, 0, H), T2 = P(0, D, H), T3 = P(L, D, H);
  let s = '<g fill="none" stroke="' + c.line + '" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">';
  // sichtbare Kanten
  s += '<path d="M' + pt(P2) + ' L' + pt(P0) + ' L' + pt(P1) + ' M' + pt(P0) + ' L' + pt(T0) + ' M' + pt(P1) + ' L' + pt(T1) + ' M' + pt(P2) + ' L' + pt(T2) + ' M' + pt(T0) + ' L' + pt(T1) + ' L' + pt(T3) + ' L' + pt(T2) + ' Z"/>';
  // verdeckte Kanten gestrichelt
  s += '<path stroke-width="1.3" stroke-dasharray="2.2 2.4" opacity=".55" d="M' + pt(P1) + ' L' + pt(P3) + ' L' + pt(P2) + ' M' + pt(P3) + ' L' + pt(T3) + '"/>';
  // Gitter auf den beiden sichtbaren Seiten (Bruchteile der Kanten)
  const mesh = [];
  for (const f of [1 / 3, 2 / 3]) { // waagerechte Linien
    mesh.push('M' + pt(P(0, 0, H * f)) + ' L' + pt(P(L, 0, H * f)));
    mesh.push('M' + pt(P(0, 0, H * f)) + ' L' + pt(P(0, D, H * f)));
  }
  for (const f of [0.25, 0.5, 0.75]) mesh.push('M' + pt(P(L * f, 0, 0)) + ' L' + pt(P(L * f, 0, H)));
  for (const f of [1 / 3, 2 / 3]) mesh.push('M' + pt(P(0, D * f, 0)) + ' L' + pt(P(0, D * f, H)));
  s += '<path stroke-width="1" opacity=".6" d="' + mesh.join(' ') + '"/>';
  s += '</g>';
  // Knotenpunkte oben
  s += '<g fill="' + c.node + '">' + [T0, T1, T2, T3].map(p => '<circle cx="' + p[0].toFixed(2) + '" cy="' + p[1].toFixed(2) + '" r="2.4"/>').join('') + '</g>';
  return s;
}
// 2) Siegel mit Gitterbox-Piktogramm, viewBox 0 0 100 100
function markBadge(c, text) {
  let s = '<circle cx="50" cy="50" r="47.5" fill="' + (c.fill || 'none') + '" stroke="' + c.ink + '" stroke-width="3"/>';
  s += '<circle cx="50" cy="50" r="33.5" fill="none" stroke="' + c.ink + '" stroke-width="1.3"/>';
  s += monoArc(text.top, { cx: 50, cy: 50, r: 36.2, size: 7.4, stroke: 2.4, spacing: 5.5, color: c.ink, top: true, center: 0 });
  s += monoArc(text.bottom, { cx: 50, cy: 50, r: 36.2, size: 7.4, stroke: 2.4, spacing: 5.5, color: c.ink, top: false, center: 180 });
  // Trenner links/rechts
  s += '<g fill="' + c.ink + '"><path transform="translate(10.1,50)" d="M0,-2.6 L2.6,0 L0,2.6 L-2.6,0 Z"/><path transform="translate(89.9,50)" d="M0,-2.6 L2.6,0 L0,2.6 L-2.6,0 Z"/></g>';
  // Piktogramm Gitterbox (Frontansicht) 44 x 37, zentriert
  s += '<g transform="translate(28,31.5)" fill="' + c.ink + '">';
  s += '<rect x="0" y="0" width="44" height="4.2" rx="1"/><rect x="0" y="0" width="3.2" height="31"/><rect x="40.8" y="0" width="3.2" height="31"/>';
  s += '<rect x="0" y="16" width="44" height="2.6"/><rect x="0" y="28" width="44" height="3.2"/>';
  s += '<g stroke="' + c.ink + '" stroke-width="1.15" fill="none"><path d="M9.5,4 V28 M16,4 V28 M22,4 V28 M28,4 V28 M34.5,4 V28 M3,8.5 H41 M3,12.5 H41 M3,22.5 H41 M3,25 H41"/></g>';
  s += '<rect x="5" y="31" width="8.5" height="6" rx=".8"/><rect x="30.5" y="31" width="8.5" height="6" rx=".8"/>';
  s += '</g>';
  return s;
}
// 3) Raster-G als Zeichen
function markBlockG(c, cell, gap) {
  return blockWord('G', { cell, gap, color: c.ink, accent: { letter: 0, row: 3, col: 4, color: c.accent } });
}

// ---------- Lockups (Logo = Zeichen + Schriftzug) ----------
const NAME = 'EUROGITTER', TAG = 'DIREKT AB LAGER';
function svgWrap(w, h, inner, extra) { return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' + w + ' ' + h + '" width="' + w + '" height="' + h + '"' + (extra || '') + '>' + inner + '</svg>'; }

const DESIGNS = {
  1: { name: 'Wireframe', file: 'entwurf-1-wireframe',
       light: { line: '#2456a4', node: '#ff6a13', word: '#1b2430', tag: '#2456a4' },
       dark:  { line: '#8fb1f2', node: '#ff8a3d', word: '#ffffff', tag: '#8fb1f2' },
       colors: [['Stahlblau', '#2456a4'], ['Tinte', '#1b2430'], ['Signalorange', '#ff6a13']],
       text: 'Technisch und modern: eine Gitterbox als isometrische Drahtgitter-Konstruktion mit orangen Knotenpunkten, dazu ein ruhiger Schriftzug in Monolinie. Wirkt wie aus dem CAD-Programm – passt zu DIN-Norm, Datenblatt und Blaupausen-Optik.' },
  2: { name: 'Siegel', file: 'entwurf-2-siegel',
       light: { ink: '#1d5c3c', word: '#1d5c3c' },
       dark:  { ink: '#f4ecd8', word: '#f4ecd8' },
       colors: [['Tannengrün', '#1d5c3c'], ['Creme', '#f4ecd8']],
       text: 'Klassisch und vertrauenswürdig: ein rundes Prüfsiegel mit Gitterbox-Piktogramm und umlaufender Schrift „Gitterbox · Direkt ab Lager“. Einfarbig, stempelbar, funktioniert auch auf Rechnung, Lieferschein und Verpackung.' },
  3: { name: 'Raster', file: 'entwurf-3-raster',
       light: { ink: '#141a22', accent: '#ff5a1f' },
       dark:  { ink: '#ffffff', accent: '#ff7a45' },
       colors: [['Tinte', '#141a22'], ['Signalorange', '#ff5a1f']],
       text: 'Kräftig und eigenständig: Schriftzug und G-Zeichen sind aus einzelnen Blöcken gebaut – wie ein Gitter. Ein einzelner oranger Block als Markenzeichen. Sehr gut lesbar, auch als winziges Favicon.' }
};

function lockup(n, variant) {
  const d = DESIGNS[n], c = d[variant];
  if (n === 1) {
    const word = monoWord(NAME, { x: 84, y: 8, size: 30, stroke: 2.3, spacing: 5.2, color: c.word });
    const tag = monoWord(TAG, { x: 85, y: 47, size: 9.5, stroke: 2.1, spacing: 6.5, color: c.tag });
    const w = Math.ceil(84 + Math.max(word.width, tag.width) + 6);
    return svgWrap(w, 64, '<g transform="translate(0,0)">' + markWire(c) + '</g>' + word.svg + tag.svg);
  }
  if (n === 2) {
    const word = monoWord(NAME, { x: 118, y: 35, size: 30, stroke: 2.9, spacing: 5.4, color: c.word });
    const w = Math.ceil(118 + word.width + 6);
    return svgWrap(w, 100, markBadge(c, { top: NAME, bottom: TAG }) + word.svg);
  }
  const mark = markBlockG(c, 9, 1.3);
  const word = blockWord(NAME, { x: 68, y: 8, cell: 7.2, gap: 1.05, letterGap: 6.6, color: c.ink, accent: { letter: 0, row: 3, col: 4, color: c.accent } });
  const w = Math.ceil(68 + word.width + 4);
  return svgWrap(w, Math.ceil(mark.height), mark.svg + word.svg);
}
function markOnly(n, variant, size) {
  const d = DESIGNS[n], c = d[variant];
  if (n === 1) return svgWrap(64, 64, markWire(c)).replace('width="64" height="64"', 'width="' + size + '" height="' + size + '"');
  if (n === 2) return svgWrap(100, 100, markBadge(c, { top: NAME, bottom: TAG })).replace('width="100" height="100"', 'width="' + size + '" height="' + size + '"');
  const m = markBlockG(c, 9, 1.3);
  const w = Math.ceil(m.width), h = Math.ceil(m.height), side = Math.max(w, h);
  return svgWrap(side, side, '<g transform="translate(' + ((side - w) / 2) + ',' + ((side - h) / 2) + ')">' + m.svg + '</g>').replace('width="' + side + '" height="' + side + '"', 'width="' + size + '" height="' + size + '"');
}
// Favicon-Variante: Zeichen auf Kachel
function favicon(n) {
  const d = DESIGNS[n];
  if (n === 1) return svgWrap(64, 64, '<rect width="64" height="64" rx="14" fill="#eef3fb"/>' + markWire(d.light));
  if (n === 2) return svgWrap(100, 100, '<circle cx="50" cy="50" r="50" fill="#f4ecd8"/>' + markBadge(d.light, { top: NAME, bottom: TAG }));
  const m = markBlockG(d.dark, 9, 1.3); const w = m.width, h = m.height, side = Math.max(w, h) + 18;
  return svgWrap(side, side, '<rect width="' + side + '" height="' + side + '" rx="' + (side * 0.2) + '" fill="#141a22"/><g transform="translate(' + ((side - w) / 2) + ',' + ((side - h) / 2) + ')">' + m.svg + '</g>');
}

// ---------- Dateien ----------
const files = [];
for (const n of [1, 2, 3]) {
  const d = DESIGNS[n];
  const put = (suffix, svg) => { const f = d.file + suffix + '.svg'; fs.writeFileSync(path.join(OUT, f), svg, 'utf8'); files.push(f); };
  put('', lockup(n, 'light')); put('-dunkel', lockup(n, 'dark')); put('-zeichen', markOnly(n, 'light', 256)); put('-favicon', favicon(n));
}

// ---------- Vorschauseite ----------
function esc(s) { return s.replace(/&/g, '&amp;').replace(/</g, '&lt;'); }
function fitSvg(svg, h) { return svg.replace(/ width="[\d.]+" height="[\d.]+"/, ' height="' + h + '" style="width:auto;max-width:100%"'); }
function card(n) {
  const d = DESIGNS[n];
  const sw = d.colors.map(c => '<span class="sw"><i style="background:' + c[1] + '"></i>' + c[0] + ' <code>' + c[1] + '</code></span>').join('');
  return '<section class="card" id="e' + n + '">' +
    '<div class="card-head"><span class="num">Entwurf ' + n + '</span><h2>' + d.name + '</h2></div>' +
    '<p class="desc">' + esc(d.text) + '</p>' +
    '<div class="stage">' + fitSvg(lockup(n, 'light'), 120) + '</div>' +
    '<div class="row">' +
      '<div class="hdr"><div class="hdr-in">' + fitSvg(lockup(n, 'light'), 46) + '<nav><span>Neue Gitterboxen</span><span>Gebraucht</span><span>EU-Paletten</span><span>Kontakt</span></nav><span class="cart">Warenkorb</span></div><div class="hint">Kopfzeile</div></div>' +
      '<div class="ftr"><div class="hdr-in">' + fitSvg(lockup(n, 'dark'), 46) + '<span class="ftr-txt">Lieferung 3–6 Werktage · Zahlungsziel 14 Werktage</span></div><div class="hint">Fußzeile</div></div>' +
    '</div>' +
    '<div class="row row-small">' +
      '<div class="box"><div class="marks">' + markOnly(n, 'light', 96) + markOnly(n, 'light', 48) + markOnly(n, 'light', 32) + markOnly(n, 'light', 16) + '</div><div class="hint">Zeichen allein · 96 / 48 / 32 / 16 px</div></div>' +
      '<div class="box"><div class="marks">' + favicon(n).replace(/ width="[\d.]+" height="[\d.]+"/, ' width="64" height="64"') + favicon(n).replace(/ width="[\d.]+" height="[\d.]+"/, ' width="32" height="32"') + favicon(n).replace(/ width="[\d.]+" height="[\d.]+"/, ' width="16" height="16"') + '</div><div class="hint">Favicon / App-Icon · 64 / 32 / 16 px</div></div>' +
      '<div class="box"><div class="swatches">' + sw + '</div><div class="hint">Farben</div></div>' +
    '</div>' +
  '</section>';
}
const html = '<!doctype html><html lang="de"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Logo-Entwürfe · Gitterbox</title><style>' +
  'body{margin:0;background:#f3f1ec;color:#141a22;font-family:Segoe UI,system-ui,Arial,sans-serif;font-size:15px;line-height:1.5}' +
  '.wrap{max-width:1180px;margin:0 auto;padding:28px 20px 60px}' +
  'h1{font-size:26px;margin:0 0 6px}.intro{color:#5f6975;margin:0 0 26px;max-width:800px}' +
  '.card{background:#fff;border:1px solid #ddd8cc;border-radius:12px;padding:22px 24px 24px;margin-bottom:26px}' +
  '.card-head{display:flex;align-items:baseline;gap:14px;margin-bottom:4px}.num{font-weight:700;color:#fff;background:#141a22;border-radius:6px;padding:2px 10px;font-size:13px;letter-spacing:.04em}h2{margin:0;font-size:22px}' +
  '.desc{margin:6px 0 16px;color:#3b4350;max-width:860px}' +
  '.stage{background:#fff;border:1px dashed #d9d4c8;border-radius:10px;padding:34px 30px;display:flex;justify-content:center;align-items:center;margin-bottom:14px;overflow:hidden}' +
  '.row{display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:14px}.row-small{grid-template-columns:1.4fr 1fr 1fr}' +
  '@media(max-width:820px){.row,.row-small{grid-template-columns:1fr}}' +
  '.hdr,.ftr{border-radius:10px;overflow:hidden;border:1px solid #e3ded2}.hdr{background:#fbfaf7}.ftr{background:#141a22;color:#fff;border-color:#141a22}' +
  '.hdr-in{display:flex;align-items:center;gap:22px;padding:14px 18px;min-height:74px;overflow:hidden}.hdr-in svg{flex:0 0 auto}' +
  'nav{display:flex;gap:16px;font-weight:600;font-size:14px;color:#1b2430;white-space:nowrap;overflow:hidden}.cart{margin-left:auto;font-size:13px;border:1.5px solid #141a22;border-radius:6px;padding:4px 10px;white-space:nowrap}' +
  '.ftr-txt{font-family:Consolas,monospace;font-size:12px;opacity:.7;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}' +
  '.hint{font-size:12px;color:#8a919b;padding:6px 12px;border-top:1px solid rgba(0,0,0,.06);background:rgba(0,0,0,.02)}.ftr .hint{color:#aab1bb;border-top-color:rgba(255,255,255,.1);background:rgba(255,255,255,.04)}' +
  '.box{background:#fbfaf7;border:1px solid #e3ded2;border-radius:10px;overflow:hidden}.marks{display:flex;align-items:flex-end;gap:22px;padding:18px;min-height:112px}.marks svg{display:block;flex:0 0 auto}' +
  '.swatches{display:flex;flex-wrap:wrap;gap:10px 18px;padding:18px;min-height:112px;align-content:center}.sw{display:flex;align-items:center;gap:8px;font-size:13px}.sw i{width:22px;height:22px;border-radius:6px;border:1px solid rgba(0,0,0,.12)}code{font-family:Consolas,monospace;font-size:12px;color:#5f6975}' +
  '.foot{color:#5f6975;font-size:13px;margin-top:6px}' +
  '</style></head><body><div class="wrap">' +
  '<h1>Logo-Entwürfe für den Gitterbox-Shop</h1>' +
  '<p class="intro">Drei komplett unterschiedliche Richtungen. Jeder Entwurf ist als Vektorgrafik gebaut und braucht keine Schriftart – der Name lässt sich später beliebig austauschen (A–Z, Ä Ö Ü, Ziffern). Gezeigt werden jeweils Logo, Kopfzeile, Fußzeile, Zeichen in kleinen Größen und Favicon.</p>' +
  card(1) + card(2) + card(3) +
  '<p class="foot">Einfach „Entwurf 1“, „2“ oder „3“ zurückmelden – Änderungswünsche (Farbe, Zusatzzeile, Name) sind schnell umgesetzt. Nach der Wahl baue ich das Logo in Kopf- und Fußzeile, Favicons, Teilen-Bild, E-Mails und Rechnung ein.</p>' +
  '</div></body></html>';
fs.writeFileSync(path.join(OUT, 'logo-entwuerfe.html'), html, 'utf8');
console.log('geschrieben:', files.join(', '), '+ logo-entwuerfe.html ->', OUT);
