// Erzeugt aus lib/logo.js alle statischen Logo-Dateien des Shops:
//   public/favicon.svg, favicon-16/32/48 -> favicon.ico, favicon-96/192/512.png, apple-touch-icon.png,
//   public/img/logo-mark.png (E-Mails) und public/og-image.jpg (Teilen-Bild, Basis: tools/og-basis.jpg).
// Aufruf: node tools/logo-build.js            (Name aus dem Admin-Impressum bzw. Standardname)
//         node tools/logo-build.js "Mein Name" (Name ausdrücklich vorgeben)
// Kopf-/Fußzeile und PDF-Rechnung brauchen das nicht – sie zeichnen das Logo live.
const fs = require('fs'), path = require('path'), os = require('os'), { spawnSync } = require('child_process');
const ROOT = path.join(__dirname, '..');
const logo = require(path.join(ROOT, 'lib', 'logo.js'));
const brand = require(path.join(ROOT, 'lib', 'brand.js'));
let name = process.argv[2];
if (!name) { try { name = require(path.join(ROOT, 'lib', 'seller.js')).info().brand; } catch (e) {} }
name = name || brand.defaultName;
const PUB = path.join(ROOT, 'public');
const TMP = fs.mkdtempSync(path.join(os.tmpdir(), 'logo-'));

// 1) SVG-Favicon (skaliert verlustfrei)
fs.writeFileSync(path.join(PUB, 'favicon.svg'), logo.faviconSvg(name), 'utf8');

// 2) Raster-Aufträge
const lines = [];
function job(out, w, h, o) { o = o || {}; lines.push(['J', 'out=' + out, 'w=' + w, 'h=' + h, 'bg=' + (o.bg || 'none'), 'fmt=' + (o.fmt || 'png'), 'q=' + (o.q || 90)].concat(o.img ? ['img=' + o.img] : []).join('\t')); }
function draw(prims, x, y, s) {
  lines.push(['S', 'x=' + x, 'y=' + y, 's=' + s].join('\t'));
  for (const p of logo.flatten(prims)) lines.push(['P', 'f=' + (p.fill || '-'), 's=' + (p.stroke || '-'), 'w=' + p.sw.toFixed(4), 'c=' + (p.closed ? 1 : 0), 'cap=' + p.cap, 'pts=' + p.pts.map(([a, b]) => a.toFixed(3) + ',' + b.toFixed(3)).join(';')].join('\t'));
}
const full = logo.badgeScene({ name, fill: logo.COLORS.cream });
const simple = logo.badgeScene({ name, fill: logo.COLORS.cream, simple: true });
for (const s of [16, 32, 48]) { job(path.join(TMP, 'favicon-' + s + '.png'), s, s); draw(simple, 0, 0, s / 100); }
for (const s of [96, 192, 512]) { job(path.join(PUB, 'favicon-' + s + 'x' + s + '.png'), s, s); draw(s < 100 ? simple : full, 0, 0, s / 100); }
job(path.join(PUB, 'apple-touch-icon.png'), 180, 180, { bg: logo.COLORS.cream }); draw(full, 180 * 0.08, 180 * 0.08, 180 * 0.84 / 100);
job(path.join(PUB, 'img', 'logo-mark.png'), 176, 176); draw(full, 0, 0, 1.76);
const basis = path.join(__dirname, 'og-basis.jpg');
let ogDone = false;
if (fs.existsSync(basis)) {
  job(path.join(PUB, 'og-image.jpg'), 1200, 630, { fmt: 'jpg', q: 88, img: basis });
  const badge = logo.badgeScene({ name, m: logo.chain(logo.T(115, 95), logo.S(2.7)) });
  let size = 44; const probe = logo.wordScene(name, { size, stroke: 2.6, spacing: 5.4, color: logo.COLORS.ink });
  if (probe.width > 440) size = size * 440 / probe.width;
  const word = logo.wordScene(name, { size, stroke: 2.6, spacing: 5.4, color: logo.COLORS.ink });
  const placed = logo.wordScene(name, { size, stroke: 2.6, spacing: 5.4, color: logo.COLORS.ink, m: logo.T(Math.max(40, 250 - word.width / 2), 420) });
  draw(badge.concat(placed.prims), 0, 0, 1);
  ogDone = true;
}
const jobsFile = path.join(TMP, 'jobs.txt');
fs.writeFileSync(jobsFile, lines.join('\n') + '\n', 'utf8');
const ps = spawnSync('powershell', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', path.join(__dirname, 'logo-raster.ps1'), '-Jobs', jobsFile], { encoding: 'utf8' });
if (ps.status !== 0) { console.error('Rasterung fehlgeschlagen:', (ps.stderr || ps.stdout || '').trim()); process.exit(1); }

// 3) favicon.ico aus 16/32/48 (PNG-Einträge)
const pngs = [16, 32, 48].map(s => ({ s, buf: fs.readFileSync(path.join(TMP, 'favicon-' + s + '.png')) }));
const hdr = Buffer.alloc(6); hdr.writeUInt16LE(0, 0); hdr.writeUInt16LE(1, 2); hdr.writeUInt16LE(pngs.length, 4);
const entries = Buffer.alloc(16 * pngs.length); let off = 6 + 16 * pngs.length;
pngs.forEach((p, i) => { const e = entries.subarray(i * 16); e[0] = p.s; e[1] = p.s; e[2] = 0; e[3] = 0; e.writeUInt16LE(1, 4); e.writeUInt16LE(32, 6); e.writeUInt32LE(p.buf.length, 8); e.writeUInt32LE(off, 12); off += p.buf.length; });
fs.writeFileSync(path.join(PUB, 'favicon.ico'), Buffer.concat([hdr, entries].concat(pngs.map(p => p.buf))));
fs.rmSync(TMP, { recursive: true, force: true });
console.log('Logo-Dateien erzeugt für „' + name + '“: favicon.svg, favicon.ico, favicon-96/192/512.png, apple-touch-icon.png, img/logo-mark.png' + (ogDone ? ', og-image.jpg' : ' (og-image.jpg übersprungen: tools/og-basis.jpg fehlt)'));
