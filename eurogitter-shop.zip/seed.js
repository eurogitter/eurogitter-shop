const db = require('./db');
const reset = process.argv.includes('--reset');

// ============================================================
//  Sortiment Gitterbox-Shop: neue Gitterboxen, geprüft gebrauchte Gitterboxen, EU-Paletten.
//  Preise netto (zzgl. 19 % MwSt). compare = üblicher Marktpreis Neuware.
//
//  Verhalten beim Start:
//   - Fehlende Produkte werden angelegt (bestehende bleiben unangetastet).
//   - Erhöht man CONTENT_VERSION, werden Texte/Bilder/Kategorien bestehender Produkte
//     EINMALIG aus dieser Datei nachgezogen. Preis, Bestand, Bestseller, Mengen und
//     Reihenfolge werden dabei NIE überschrieben (Admin-Änderungen bleiben erhalten).
// ============================================================
const CONTENT_VERSION = 2;

const PRODUCTS = [
  // ============ Neue Gitterboxen ============
  { slug:'db-europool-gitterbox-halbe-klappe', name:'DB-Europool-Gitterbox mit halber Klappe (EPAL-Stempel)', type:'Halbe Klappe · EPAL-tauschfähig · Steingrau (RAL 7030)', category:'mit-klappe', group:'gitterbox', bestseller:1, min_order:10,
    dimensions:'1.240 × 835 × 970 mm', load_capacity:'Nutzlast 1.500 kg · Auflast 6.000 kg',
    short_desc:'Die genormte Tausch-Gitterbox mit EPAL-Stempel – auch als DB-Gitterbox, Euro-Gitterbox oder EPAL-Gitterbox bekannt. Halb abklappbare Längswand, im europäischen Palettenpool voll tauschfähig.',
    description:'Die klassische Euro-Gitterbox nach DIN 15155/8 und UIC 435-3 mit EPAL-Stempel. Ob DB-Gitterbox, Euro-Gitterbox, EPAL-Gitterbox oder Europool-Gitterbox: Gemeint ist immer derselbe genormte Tauschbehälter des europäischen Palettenpools. Früher wurden die Boxen mit DB-Stempel geliefert, heute tragen alle neu gefertigten Boxen den EPAL-Stempel – beide sind im Pool gleichwertig tauschbar. Eine Längswand ist halb abklappbar, dadurch lässt sich die Box bequem be- und entladen. Voll tauschfähig, 5-fach stapelbar und fabrikneu ab Lager.',
    features:['100 % original mit EPAL-Stempel · im Europool voll tauschfähig (keine Nachbauten)','Norm DIN 15155/8 · UIC 435-3','Stahl · lackiert RAL 7030 Steingrau','Halbe Klappe (Längswand)','Nutzlast 1.500 kg · 5-fach stapelbar','Innenmaß 1.200 × 800 mm · Gitter 50 × 50 mm · 5-fach stapelbar · Unterfahrhöhe 100 mm'], price_cents:9900, compare_cents:null, image:'db-europool-gitterbox-halbe-klappe.jpg', gallery:['db-europool-gitterbox-halbe-klappe-2.jpg','db-europool-gitterbox-halbe-klappe-3.jpg'], sort_order:10 },

  { slug:'euro-gitterbox-mit-deckel', name:'Euro-Gitterbox mit Deckel · abschließbar', type:'Mit Deckel · abschließbar', category:'mit-klappe', group:'gitterbox', bestseller:1, min_order:10,
    dimensions:'1.240 × 835 × 970 mm · Nutzhöhe 800 mm', load_capacity:'Nutzlast 1.500 kg',
    short_desc:'Mit aufliegendem Gitterdeckel und Vorrichtung für ein Vorhängeschloss.',
    description:'Euro-Gitterbox mit aufliegendem Gitterdeckel und Vorrichtung für ein Vorhängeschloss. Der Deckel schützt das Ladegut und ermöglicht sicheres, verschlossenes Lagern und Stapeln – ideal für wertige oder sensible Waren. Oberfläche: pulverbeschichtet/lackiert in Steingrau.',
    features:['Inkl. Gitterdeckel','Vorrichtung für Vorhängeschloss','Stahl · lackiert (Steingrau)','Halbe Klappe · Nutzlast 1.500 kg','Innenmaß 1.200 × 800 mm · Gitter 50 × 50 mm · 5-fach stapelbar · Unterfahrhöhe 100 mm'], price_cents:12900, compare_cents:null, image:'euro-gitterbox-mit-deckel.jpg', gallery:['euro-gitterbox-mit-deckel-2.jpg','euro-gitterbox-mit-deckel-3.jpg'], sort_order:30 },

  { slug:'euro-gitterbox-schwarz-mit-deckel', name:'Euro-Gitterbox mit Deckel in Tiefschwarz', type:'Mit Deckel · Tiefschwarz', category:'lackiert', group:'gitterbox', bestseller:0, min_order:10,
    dimensions:'1.240 × 835 × 970 mm · Nutzhöhe 800 mm', load_capacity:'Nutzlast 1.500 kg',
    short_desc:'Abschließbare Gitterbox mit Deckel im edlen Tiefschwarz.',
    description:'Abschließbare Euro-Gitterbox mit Deckel, pulverbeschichtet im edlen Tiefschwarz. Mit Vorrichtung für ein Vorhängeschloss – hochwertiger Industrial-Look für sichtbare Lager- und Verkaufsbereiche.',
    features:['Deckel · abschließbar','Tiefschwarz (RAL 9005)','Halbe Klappe · Nutzlast 1.500 kg','Innenmaß 1.200 × 800 mm · Gitter 50 × 50 mm · 5-fach stapelbar · Unterfahrhöhe 100 mm'], price_cents:13900, compare_cents:null, image:'euro-gitterbox-schwarz-mit-deckel.jpg', gallery:['euro-gitterbox-schwarz-mit-deckel-2.jpg','euro-gitterbox-schwarz-mit-deckel-3.jpg'], sort_order:40 },

  { slug:'euro-gitterbox-feuerverzinkt-mit-deckel', name:'Euro-Gitterbox feuerverzinkt mit Deckel', type:'Feuerverzinkt · mit Deckel', category:'ohne-klappe', group:'gitterbox', bestseller:0, min_order:10,
    dimensions:'1.240 × 835 × 970 mm', load_capacity:'Nutzlast 1.500 kg · Auflast 6.000 kg',
    short_desc:'Feuerverzinkt mit Sickenblechboden und Deckel – maximaler Korrosionsschutz.',
    description:'Feuerverzinkte Euro-Gitterbox mit Sickenblechboden und aufliegendem Deckel samt Vorrichtung für ein Vorhängeschloss. Der Zink-Tauchüberzug bietet dauerhaften Korrosionsschutz – auch für den dauerhaften Außeneinsatz geeignet.',
    features:['Feuerverzinkt (Zink-Tauchbad)','Sickenblechboden','Deckel · abschließbar','Nutzlast 1.500 kg · Auflast 6.000 kg','Innenmaß 1.200 × 800 mm · Gitter 50 × 50 mm · 5-fach stapelbar · Unterfahrhöhe 100 mm'], price_cents:19900, compare_cents:null, image:'euro-gitterbox-feuerverzinkt-mit-deckel.jpg', gallery:['euro-gitterbox-feuerverzinkt-mit-deckel-2.jpg','euro-gitterbox-feuerverzinkt-mit-deckel-3.jpg'], sort_order:50 },

  { slug:'halbhohe-gitterbox-ohne-klappe', name:'Halbhohe Gitterbox ohne Klappe', type:'Halbhoch · ohne Klappe', category:'sondermasse', group:'gitterbox', bestseller:0, min_order:10,
    dimensions:'1.240 × 835 mm · Höhe 500 oder 570 mm', load_capacity:'Nutzlast 1.500 kg',
    short_desc:'Niedrige Bauform, keine Seite abklappbar – maximal stabil.',
    description:'Halbhohe Gitterbox in niedriger Bauform mit vier festen Seiten. Besonders stabil und platzsparend, gut geeignet für Schüttgut und schnelles Befüllen. Oberfläche: pulverbeschichtet/lackiert in Steingrau. Lieferbar mit 500 oder 570 mm Nutzhöhe.',
    features:['Niedrige Bauform','Vier feste Seiten','Stahl · lackiert (Steingrau)','Nutzlast 1.500 kg','Höhe 500/570 mm · Gitter 50 × 50 mm · stapelbar · Unterfahrhöhe 100 mm'], price_cents:8400, compare_cents:null, image:'halbhohe-gitterbox-ohne-klappe.jpg', gallery:['halbhohe-gitterbox-ohne-klappe-2.jpg','halbhohe-gitterbox-ohne-klappe-3.jpg'], sort_order:60 },

  { slug:'halbhohe-gitterbox-halb-abklappbar', name:'Halbhohe Gitterbox mit halber Klappe', type:'Halbhoch · halbe Klappe', category:'sondermasse', group:'gitterbox', bestseller:0, min_order:10,
    dimensions:'1.240 × 835 mm · Höhe 500 oder 570 mm', load_capacity:'Nutzlast 1.500 kg',
    short_desc:'Niedrige Bauform mit halb abklappbarer Längsseite.',
    description:'Halbhohe Gitterbox mit einer halb abklappbaren Längsseite für bequemen Zugriff bei niedriger Bauhöhe. Platzsparend und gut stapelbar, Oberfläche pulverbeschichtet/lackiert in Steingrau, lieferbar mit 500 oder 570 mm Nutzhöhe.',
    features:['Niedrige Bauform','Längsseite halb abklappbar','Stahl · lackiert (Steingrau)','Nutzlast 1.500 kg','Höhe 500/570 mm · Gitter 50 × 50 mm · stapelbar · Unterfahrhöhe 100 mm'], price_cents:8400, compare_cents:null, image:'halbhohe-gitterbox-halb-abklappbar.jpg', gallery:['halbhohe-gitterbox-halb-abklappbar-2.jpg'], sort_order:70 },

  { slug:'halbhohe-gitterbox-voll-abklappbar', name:'Halbhohe Gitterbox mit ganzer Klappe', type:'Halbhoch · ganze Klappe', category:'sondermasse', group:'gitterbox', bestseller:1, min_order:10,
    dimensions:'1.240 × 835 mm · Höhe 500 oder 570 mm', load_capacity:'Nutzlast 1.500 kg',
    short_desc:'Niedrige Bauform mit voll abklappbarer Längsseite.',
    description:'Halbhohe Gitterbox mit einer voll abklappbaren Längsseite – maximaler Zugriff bei niedriger Bauhöhe. Ideal zum schnellen Ein- und Auslagern, Oberfläche pulverbeschichtet/lackiert in Steingrau, lieferbar mit 500 oder 570 mm Nutzhöhe.',
    features:['Niedrige Bauform','Längsseite voll abklappbar','Stahl · lackiert (Steingrau)','Nutzlast 1.500 kg','Höhe 500/570 mm · Gitter 50 × 50 mm · stapelbar · Unterfahrhöhe 100 mm'], price_cents:8900, compare_cents:null, image:'halbhohe-gitterbox-voll-abklappbar.jpg', gallery:['halbhohe-gitterbox-voll-abklappbar-2.jpg'], sort_order:80 },

  { slug:'halbhohe-gitterbox-klappbare-schmalseite', name:'Halbhohe Gitterbox mit klappbarer Schmalseite', type:'Halbhoch · Schmalseite', category:'sondermasse', group:'gitterbox', bestseller:0, min_order:10,
    dimensions:'1.240 × 835 mm · Höhe 500 oder 570 mm', load_capacity:'Nutzlast 1.500 kg',
    short_desc:'Ergonomisches Ein- und Auslagern über die klappbare Schmalseite.',
    description:'Halbhohe Gitterbox, bei der die Schmalseite klappbar ist – das erlaubt besonders ergonomisches Ein- und Auslagern, etwa an Montage- und Kommissionierplätzen. Oberfläche: pulverbeschichtet/lackiert in Steingrau.',
    features:['Niedrige Bauform','Schmalseite klappbar','Stahl · lackiert (Steingrau)','Nutzlast 1.500 kg','Höhe 500/570 mm · Gitter 50 × 50 mm · stapelbar · Unterfahrhöhe 100 mm'], price_cents:9900, compare_cents:null, image:'halbhohe-gitterbox-klappbare-schmalseite.jpg', gallery:[], sort_order:90 },

  // ============ EU-Paletten (neu) ============
  { slug:'epal-europalette-1200x800-neu', name:'EPAL Europalette 1200 × 800 (neu)', type:'EPAL / EUR', category:'euro-palette', group:'palette', bestseller:1,
    dimensions:'1.200 × 800 × 144 mm', load_capacity:'dynamisch bis 1.500 kg',
    short_desc:'Fabrikneue EPAL/EUR-Europalette, IPPC/ISPM-15, kammergetrocknet.',
    description:'Fabrikneue EPAL-Europalette nach Norm, IPPC/ISPM-15-behandelt und kammergetrocknet – die meistgenutzte Palette Europas. Ideal für Lager, Transport, Palettentausch und weltweiten Export.',
    features:['EPAL/EUR-Norm, fabrikneu','IPPC / ISPM-15','Kammergetrocknet','Dynamisch bis 1.500 kg'], price_cents:1290, compare_cents:null, image:'pal-epal.svg', sort_order:210 },

  { slug:'einwegpalette-1200x800-neu', name:'Einwegpalette 1200 × 800 (neu)', type:'Einweg · Euro-Maß', category:'einweg-palette', group:'palette', bestseller:1,
    dimensions:'1.200 × 800 × 130 mm', load_capacity:'bis 900 kg',
    short_desc:'Neue, leichte Einwegpalette im Euro-Maß, IPPC.',
    description:'Fabrikneue Einwegpalette im Euro-Maß, IPPC-behandelt – die günstige Lösung für Versand und Einwegtransporte ohne Rückführung.',
    features:['Fabrikneu, IPPC','Euro-Maß 1200 × 800','4-Wege-Einfahrt','Leicht & günstig'], price_cents:870, compare_cents:null, image:'pal-einweg.svg', sort_order:220 },

  { slug:'duesseldorfer-palette-800x600-neu', name:'Düsseldorfer Palette 800 × 600 (neu)', type:'Halbpalette', category:'duesseldorfer-palette', group:'palette', bestseller:0,
    dimensions:'800 × 600 × 144 mm', load_capacity:'bis 500 kg',
    short_desc:'Neue Düsseldorfer Halbpalette – ideal für Handel & Display.',
    description:'Fabrikneue Düsseldorfer Palette (Halbpalette) im Maß 800 × 600 mm – Standard für den Warenfluss zwischen Industrie und Handel, ideal für Displays im Einzelhandel.',
    features:['Halbpalette 800 × 600','Fabrikneu','Handel/Display geeignet','Robust'], price_cents:690, compare_cents:null, image:'pal-duesseldorf.svg', sort_order:230 },

  { slug:'industriepalette-1200x1000-neu', name:'Industriepalette 1200 × 1000 (neu)', type:'Industrie / Pool', category:'industrie-palette', group:'palette', bestseller:0,
    dimensions:'1.200 × 1.000 × 162 mm', load_capacity:'dynamisch bis 1.500 kg',
    short_desc:'Neue Industriepalette mit größerer Grundfläche, IPPC.',
    description:'Fabrikneue Industriepalette (Poolpalette) im Maß 1200 × 1000 mm, IPPC-behandelt – robuste Ausführung für schwere Güter und die chemische Industrie.',
    features:['Industriemaß 1200 × 1000','Fabrikneu, IPPC','Besonders robust','Dynamisch bis 1.500 kg'], price_cents:1490, compare_cents:null, image:'pal-industrie.svg', sort_order:240 },

  { slug:'einweg-industriepalette-1200x1000-neu', name:'Einweg-Industriepalette 1200 × 1000 (neu)', type:'Einweg · Industriemaß', category:'einweg-palette', group:'palette', bestseller:0,
    dimensions:'1.200 × 1.000 × 138 mm', load_capacity:'bis 1.000 kg',
    short_desc:'Neue, günstige Einwegpalette im Industriemaß, IPPC.',
    description:'Fabrikneue Einweg-Industriepalette im Maß 1200 × 1000 mm, IPPC-behandelt – günstige Einweglösung für den Versand großflächiger oder schwerer Güter.',
    features:['Industriemaß 1200 × 1000','Fabrikneu, IPPC','Einweg / Export','bis 1.000 kg'], price_cents:1090, compare_cents:null, image:'pal-industrie-einweg.svg', sort_order:250 },

  { slug:'kunststoffpalette-1200x800-neu', name:'Kunststoffpalette 1200 × 800 (neu)', type:'Kunststoff · Hygiene', category:'kunststoff-palette', group:'palette', bestseller:0,
    dimensions:'1.200 × 800 × 160 mm', load_capacity:'dynamisch bis 1.250 kg',
    short_desc:'Neue Hygiene-Kunststoffpalette – abwaschbar, langlebig, ISPM-frei.',
    description:'Fabrikneue Kunststoffpalette im Euro-Maß 1200 × 800 mm – leicht zu reinigen, feuchtigkeitsbeständig und ohne ISPM-15-Pflicht. Ideal für Lebensmittel, Pharma und Export.',
    features:['Hygienisch & abwaschbar','Keine ISPM-15-Pflicht','Feuchtigkeitsbeständig','Dynamisch bis 1.250 kg'], price_cents:2490, compare_cents:null, image:'pal-kunststoff.svg', sort_order:260 },

  // ============ Gebrauchte Gitterboxen (geprüfte Gebrauchtware) ============
  { slug:'db-europool-gitterbox-halbe-klappe-gebraucht', name:'DB-Europool-Gitterbox mit halber Klappe (EPAL-Stempel) – geprüft gebraucht', type:'Geprüft gebraucht · EPAL-tauschfähig · Steingrau (RAL 7030)', category:'mit-klappe', group:'gebraucht', bestseller:0, min_order:10,
    dimensions:'1.240 × 835 × 970 mm', load_capacity:'Nutzlast 1.500 kg · Auflast 6.000 kg',
    short_desc:'Geprüfte gebrauchte Tausch-Gitterbox mit EPAL-Stempel – auch als DB-Gitterbox oder Euro-Gitterbox bekannt. Gereinigt, funktionsgeprüft und im europäischen Palettenpool voll tauschfähig.',
    description:'Geprüfte gebrauchte Euro-Gitterbox nach DIN 15155/8 und UIC 435-3 mit EPAL-Stempel und halb abklappbarer Längswand. Ob DB-Gitterbox, Euro-Gitterbox, EPAL-Gitterbox oder Europool-Gitterbox: Gemeint ist immer derselbe genormte Tauschbehälter des europäischen Palettenpools – unsere Boxen tragen den EPAL-Stempel und sind damit voll tauschfähig. Jede Box wird von uns gesichtet, gereinigt und auf Funktion geprüft – Top-Zustand mit nur leichten Gebrauchsspuren, voll einsatzfähig. 5-fach stapelbar, sofort ab Lager und deutlich günstiger als Neuware.',
    features:['100 % original mit EPAL-Stempel · im Europool voll tauschfähig (keine Nachbauten)','Geprüfte Gebrauchtware · gereinigt & funktionsgeprüft','Nur leichte Gebrauchsspuren · voll einsatzfähig','Stahl · lackiert RAL 7030 Steingrau','Norm DIN 15155/8 · UIC 435-3','Halbe Klappe (Längswand) · 5-fach stapelbar','Innenmaß 1.200 × 800 mm · Gitter 50 × 50 mm · Unterfahrhöhe 100 mm'], price_cents:6900, compare_cents:null, image:'db-europool-gitterbox-halbe-klappe-gebraucht.jpg', gallery:['gebraucht-lager-front.jpg','gebraucht-epal-stempel.jpg','db-europool-gitterbox-halbe-klappe-gebraucht-2.jpg','db-europool-gitterbox-halbe-klappe-gebraucht-3.jpg'], sort_order:300 },

  { slug:'euro-gitterbox-mit-deckel-gebraucht', name:'Euro-Gitterbox mit Deckel · abschließbar – geprüft gebraucht', type:'Geprüft gebraucht · mit Deckel', category:'mit-klappe', group:'gebraucht', bestseller:0, min_order:10,
    dimensions:'1.240 × 835 × 970 mm · Nutzhöhe 800 mm', load_capacity:'Nutzlast 1.500 kg',
    short_desc:'Geprüfte gebrauchte Gitterbox mit aufliegendem Gitterdeckel und Vorrichtung für ein Vorhängeschloss – gereinigt und funktionsgeprüft.',
    description:'Geprüfte gebrauchte Euro-Gitterbox mit aufliegendem Gitterdeckel und Vorrichtung für ein Vorhängeschloss. Von uns gesichtet, gereinigt und auf Funktion geprüft – Top-Zustand mit nur leichten Gebrauchsspuren. Ideal zum sicheren, verschlossenen Lagern und Stapeln, sofort ab Lager und spürbar günstiger als Neuware.',
    features:['Geprüfte Gebrauchtware · gereinigt & funktionsgeprüft','Nur leichte Gebrauchsspuren · voll einsatzfähig','Stahl · lackiert (Steingrau)','Inkl. Gitterdeckel · Vorrichtung für Vorhängeschloss','Nutzlast 1.500 kg · 5-fach stapelbar','Innenmaß 1.200 × 800 mm · Gitter 50 × 50 mm · Unterfahrhöhe 100 mm'], price_cents:8900, compare_cents:null, image:'euro-gitterbox-mit-deckel-gebraucht.jpg', gallery:['gebraucht-lager-front.jpg','euro-gitterbox-mit-deckel-gebraucht-2.jpg','euro-gitterbox-mit-deckel-gebraucht-3.jpg'], sort_order:310 },

  // ============ Zubehoer ============
  { slug:'gitterbox-trennwand', name:'Trennwand für Gitterboxen · einhängbar', type:'Zubehör · Quertrennwand · Gitter 50 × 50 mm', category:'trennwand', group:'zubehoer', bestseller:1, min_order:5,
    dimensions:'ca. 800 × 800 mm · passend für DIN-Gitterboxen 1.240 × 835 × 970 mm', load_capacity:'',
    short_desc:'Teilt Ihre Gitterbox in zwei Fächer – einfach ins Gitter einhängen, ohne Werkzeug, beliebig versetzbar.',
    description:'Mit der einhängbaren Trennwand machen Sie aus einer Gitterbox zwei saubere Fächer: Verschiedene Artikel, Chargen oder Auftragsteile lagern getrennt, verrutschen nicht und lassen sich schneller kommissionieren. Die Trennwand wird einfach von oben in die Längswände der Box eingehängt – ohne Werkzeug, im 50-mm-Raster beliebig versetzbar und jederzeit wieder entnehmbar. Das stabile Stahlgitter im Raster 50 × 50 mm entspricht dem Gitter der DIN-Gitterbox und passt zu neuen wie gebrauchten Boxen. Tipp: Beim Kauf einer tauschfähigen DB-Europool-Gitterbox (neu oder geprüft gebraucht) buchen Sie die Trennwände direkt zum Set-Preis von 30,00 € statt 40,00 € je Stück dazu – eine Trennwand je Box.',
    features:['Passend für DIN-Gitterboxen 1.240 × 835 × 970 mm (Innenmaß 1.200 × 800 mm)','Einhängen ohne Werkzeug · im 50-mm-Raster versetzbar','Stabiles Stahlgitter 50 × 50 mm · verzinkt / grau','Teilt die Box in zwei Fächer · ideal für Mischware und Kommissionierung','Set-Preis 30,00 € je Stück beim Kauf einer tauschfähigen DB-Europool-Box','Mindestbestellmenge 5 Stück'],
    price_cents:4000, compare_cents:null, image:'gitterbox-trennwand.jpg', gallery:['gitterbox-trennwand-2.jpg','gitterbox-trennwand-3.jpg'], sort_order:300 },

  { slug:'gitterboxzange', name:'Gitterboxzange · Öffnungszange für Klappen', type:'Zubehör · Werkzeug · 2-Komponenten-Griff', category:'werkzeug', group:'zubehoer', bestseller:0, min_order:1,
    dimensions:'', load_capacity:'',
    short_desc:'Öffnet und schließt die Klappen-Verriegelung von Gitterboxen mühelos – ohne Kraftaufwand, ohne Verletzungsgefahr.',
    description:'Wer täglich Gitterboxen be- und entlädt, kennt das Problem: Die Riegel der Klappen sitzen fest, die Finger leiden. Die Gitterboxzange setzt genau dort an – sie wird zwischen Halteblech und Riegel angesetzt, und mit einem Druck auf die Griffe zieht sie den Riegel sauber aus der Raste. Klappe auf, Klappe zu, ohne Kraftaufwand und ohne Quetschungen. Das optimierte Hebelverhältnis und der ergonomische 2-Komponenten-Griff machen die Zange zum Standardwerkzeug an Packplatz, Wareneingang und Kommissionierplatz. Passend für alle Gitterboxen nach DIN 15155 / UIC 435-3 mit Riegelverschluss.',
    features:['Für Gitterboxen nach DIN 15155 / UIC 435-3 mit Riegelverschluss','Optimiertes Hebelverhältnis · kaum Kraftaufwand','Ergonomischer 2-Komponenten-Griff','Schont Hände und Klappenmechanik','Robuste Stahlausführung für den Dauereinsatz','Einzeln bestellbar – keine Mindestmenge'],
    price_cents:4500, compare_cents:null, image:'gitterboxzange.jpg', gallery:[], sort_order:310 },

  { slug:'galia-kartentasche-gedrahtet', name:'Dokumentenhalter · Galia-Kartentasche gedrahtet', type:'Zubehör · Kennzeichnung · für Etiketten DIN A5 quer', category:'kennzeichnung', group:'zubehoer', bestseller:0, min_order:5,
    dimensions:'für Galia-/VDA-Etiketten 210 × 148 mm (DIN A5 quer)', load_capacity:'',
    short_desc:'Hält Lieferschein, Fertigungsauftrag oder Galia-Etikett gut sichtbar an der Gitterbox – einfach ins Gitter einhängen.',
    description:'Die gedrahtete Galia-Kartentasche bringt Ordnung in die Warenkennzeichnung: Lieferscheine, Fertigungsaufträge, Bestandslisten oder Barcode-Etiketten im Galia-/VDA-Format (DIN A5 quer) stecken sicher in der Metalltasche und sind auf einen Blick lesbar. Die angeschweißten Drahtbügel werden einfach ins Gitter der Box eingehängt – ohne Werkzeug, schnell versetzbar und immer wieder verwendbar. Aus stabilem Stahlblech, unempfindlich gegen Stöße und Nässe im Lageralltag. Passend für Gitterboxen nach DIN 15155, Gitteraufsatzrahmen und andere Ladungsträger mit Drahtgitter.',
    features:['Für Galia-/VDA-Etiketten 210 × 148 mm (DIN A5 quer)','Drahtbügel zum Einhängen ins Gitter · ohne Werkzeug','Stahlblech · stoß- und witterungsbeständig','Wiederverwendbar · schnell versetzbar','Passend für DIN-Gitterboxen und Gitteraufsatzrahmen','Mindestbestellmenge 5 Stück'],
    price_cents:999, compare_cents:null, image:'galia-kartentasche-gedrahtet.jpg', gallery:[], sort_order:320 },
];

// Anfangsbestand je Produkt (wird nur EINMALIG gesetzt, danach reine Admin-Sache).
const STOCK = {
  'db-europool-gitterbox-halbe-klappe': 98, 'euro-gitterbox-mit-deckel': 47,
  'euro-gitterbox-schwarz-mit-deckel': 45, 'euro-gitterbox-feuerverzinkt-mit-deckel': 49, 'halbhohe-gitterbox-ohne-klappe': 54,
  'halbhohe-gitterbox-halb-abklappbar': 51, 'halbhohe-gitterbox-voll-abklappbar': 48, 'halbhohe-gitterbox-klappbare-schmalseite': 46,
  'epal-europalette-1200x800-neu': 640, 'einwegpalette-1200x800-neu': 820, 'duesseldorfer-palette-800x600-neu': 360,
  'industriepalette-1200x1000-neu': 240, 'einweg-industriepalette-1200x1000-neu': 300, 'kunststoffpalette-1200x800-neu': 180,
  'db-europool-gitterbox-halbe-klappe-gebraucht': 321, 'euro-gitterbox-mit-deckel-gebraucht': 64,
};

// Deterministische, stabile Schein-Bewertung je Produkt (Optik):
// Bestseller = 5,0 Sterne, sonst 4,5–5,0; Gebrauchtware 4,5–4,8 mit mehr Bewertern.
function seedRating(p) {
  let h = 0; for (const c of p.slug) h = (h * 31 + c.charCodeAt(0)) >>> 0;
  if (p.group === 'gebraucht') { const g = [4.5, 4.6, 4.7, 4.8]; return { avg: g[h % g.length], count: 234 + (h % 149) }; }
  const count = 50 + (h % 111);
  if (p.bestseller) return { avg: 5.0, count };
  const opts = [4.5, 4.6, 4.7, 4.8, 4.9, 5.0];
  return { avg: opts[h % opts.length], count };
}

const insert = db.prepare(`INSERT INTO products
  (slug,name,type,category,product_group,bestseller,sold_out,min_order,max_order,rating_seed_avg,rating_seed_count,dimensions,load_capacity,short_desc,description,features,price_cents,compare_cents,image,gallery,color_options,sort_order,stock,active)
  VALUES (@slug,@name,@type,@category,@group,@bestseller,@sold_out,@min_order,@max_order,@rating_seed_avg,@rating_seed_count,@dimensions,@load_capacity,@short_desc,@description,@features,@price_cents,@compare_cents,@image,@gallery,@color_options,@sort_order,@stock,1)
  ON CONFLICT(slug) DO NOTHING`);

function row(r) {
  return {
    slug: r.slug, name: r.name, type: r.type, category: r.category, group: r.group,
    dimensions: r.dimensions || '', load_capacity: r.load_capacity || '',
    short_desc: r.short_desc || '', description: r.description || '',
    features: JSON.stringify(r.features || []),
    image: r.image || '', gallery: JSON.stringify(r.gallery || []),
    color_options: JSON.stringify(r.color_options || []),
  };
}
const insertMany = db.transaction((rows) => {
  for (const r of rows) {
    const sr = seedRating(r);
    insert.run(Object.assign(row(r), {
      bestseller: r.bestseller ? 1 : 0, sold_out: r.sold_out ? 1 : 0,
      min_order: r.min_order || 1, max_order: r.max_order || 200,
      rating_seed_avg: sr.avg, rating_seed_count: sr.count,
      price_cents: r.price_cents, compare_cents: (r.compare_cents == null ? null : r.compare_cents),
      sort_order: r.sort_order || 0,
      stock: (r.stock == null ? null : r.stock),
    }));
  }
});

function seedProducts() {
  insertMany(PRODUCTS);
  // Beschreibende Inhalte EINMALIG nachziehen, wenn CONTENT_VERSION erhöht wurde.
  try {
    const cur = parseInt(((db.prepare("SELECT value FROM settings WHERE key='seed_content_version'").get() || {}).value) || '0', 10) || 0;
    if (cur < CONTENT_VERSION) {
      const upd = db.prepare(`UPDATE products SET name=@name, type=@type, category=@category, product_group=@group,
        dimensions=@dimensions, load_capacity=@load_capacity, short_desc=@short_desc, description=@description,
        features=@features, image=@image, gallery=@gallery, color_options=@color_options WHERE slug=@slug`);
      const tx = db.transaction(() => { for (const r of PRODUCTS) upd.run(row(r)); });
      tx();
      db.prepare("INSERT OR REPLACE INTO settings (key,value) VALUES ('seed_content_version',?)").run(String(CONTENT_VERSION));
    }
  } catch (e) { console.error('Seed-Inhalte:', e.message); }
  // Anfangsbestand EINMALIG setzen (ein Flag verhindert, dass ein im Admin geleerter Bestand wieder gefüllt wird).
  try {
    const seeded = db.prepare("SELECT value FROM settings WHERE key='stock_seeded'").get();
    if (!seeded) {
      const setStock = db.prepare('UPDATE products SET stock=? WHERE slug=? AND stock IS NULL');
      for (const slug of Object.keys(STOCK)) setStock.run(STOCK[slug], slug);
      db.prepare("INSERT OR REPLACE INTO settings (key,value) VALUES ('stock_seeded','1')").run();
    }
  } catch (e) {}
  // Bestseller je Gruppe sicherstellen: Hat eine Gruppe keinen Bestseller, wird das
  // teuerste aktive Produkt der Gruppe zum Bestseller (Admin-Auswahl hat Vorrang).
  try {
    const groups = db.prepare("SELECT DISTINCT product_group AS g FROM products WHERE active=1 AND image IS NOT NULL AND image!=''").all();
    for (const g of groups) {
      if (g.g === 'gebraucht') continue; // Gebrauchtware bewusst ohne Bestseller-Kennzeichnung (wie im alten Shop)
      const has = db.prepare('SELECT COUNT(*) AS n FROM products WHERE product_group=? AND bestseller=1').get(g.g).n;
      if (!has) { const top = db.prepare("SELECT id FROM products WHERE product_group=? AND active=1 AND image IS NOT NULL AND image!='' ORDER BY price_cents DESC, id LIMIT 1").get(g.g); if (top) db.prepare('UPDATE products SET bestseller=1 WHERE id=?').run(top.id); }
    }
  } catch (e) {}
}

if (require.main === module) {
  if (reset) {
    db.prepare('DELETE FROM products').run();
    try { db.prepare('DELETE FROM carts').run(); } catch (e) {}
    try { db.prepare('DELETE FROM user_carts').run(); } catch (e) {}
    try { db.prepare("DELETE FROM settings WHERE key IN ('stock_seeded','seed_content_version')").run(); } catch (e) {}
    console.log('Bestehende Produkte gelöscht (Warenkörbe geleert).');
  }
  seedProducts();
  const total = db.prepare('SELECT COUNT(*) AS n FROM products').get().n;
  console.log(`Seed fertig: ${total} Produkte in der Datenbank.`);
}

module.exports = { PRODUCTS, seedProducts };
